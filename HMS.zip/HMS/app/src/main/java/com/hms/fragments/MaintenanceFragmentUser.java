package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;

import java.util.ArrayList;
import java.util.HashMap;
import com.hms.Model.Month;


/**.
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragmentUser extends Fragment {
    View view;

    TextView jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec;

    String yearSpinnerfirst, yearSpinnerSecond, monthSpinnerSecond, accountsFirebase, getEmail;
    String emailFromFirebase, getEmailValue;

    String month, monthValue;

    String arrayMonth[], arrayMonthValue[] ;
    int i = 0;

    Boolean checkedEmail = false;
    Boolean checkedValueAnswer = false;
    DatabaseReference maintenancefetch = FirebaseDatabase.getInstance().getReference().child("Accounts");
    Spinner yearSpinner;
    Spinner monthSpinnerPdf;
    Spinner yearSpinnerPdf;
    Button downloadPdf;
    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    public MaintenanceFragmentUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // return inflater.inflate(R.layout.MaintenanceFragmentUser, container, false);
        view = inflater.inflate(R.layout.fragment_maintenance_user, container, false);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");
        DatabaseReference maintenancefetch = FirebaseDatabase.getInstance().getReference().child("Accounts");

        jan = view.findViewById(R.id.janStatus);
        feb = view.findViewById(R.id.febStatus);
        mar = view.findViewById(R.id.marStatus);
        apr = view.findViewById(R.id.aprStatus);
        may = view.findViewById(R.id.mayStatus);
        jun = view.findViewById(R.id.janStatus);
        jul = view.findViewById(R.id.julStatus);
        aug = view.findViewById(R.id.augStatus);
        sep = view.findViewById(R.id.sepStatus);
        oct = view.findViewById(R.id.octStatus);
        dec = view.findViewById(R.id.decStatus);

        yearSpinner= view.findViewById(R.id.yearspinneruser);
        monthSpinnerPdf= view.findViewById(R.id.monthspinnerpdf);
        yearSpinnerPdf = view.findViewById(R.id.yearspinnerpdf);

        downloadPdf = view.findViewById(R.id.downloadpdf);

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);

        yearSpinner.setAdapter(adapterYears);
        monthSpinnerPdf.setAdapter(adapterMonths);
        yearSpinnerPdf.setAdapter(adapterYears);

        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerfirst = yearSpinner.getItemAtPosition(i).toString();
                Toast.makeText(getActivity(), yearSpinnerfirst, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        monthSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                monthSpinnerSecond = monthSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        yearSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerSecond = yearSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        downloadPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        //name of the accounts
        ref.addChildEventListener(new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try{
                    accountsFirebase = dataSnapshot.getKey(); //Deepak Jain
                    System.out.println("Account"+ "  " +accountsFirebase);
                    checkedValueAnswer = getEmailKey(accountsFirebase);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        return view;
    }

    //get email as a key
    public boolean getEmailKey(String accounts){//Deepak Jain
        try {
            DatabaseReference refEmail = FirebaseDatabase.getInstance().getReference().child("Accounts").child(accounts);//Deepak Jain

        final String accountsValue = accounts;//Deepak Jain

        refEmail.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    //True if the authentication and database(email) matches
                    if (checkedEmail == true) {
                        Toast.makeText(getActivity(), "Email Verified", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (checkedEmail == false){
                        getEmail = String.valueOf(dataSnapshot.getKey());//EmailId
                        getEmailValue = String.valueOf(dataSnapshot.getValue(String.class));//deepak.jain186@gmail.com

                        System.out.println(getEmail + " " + getEmailValue);
                        //true
                        if (getEmail.equals("EmailId")) {

                            System.out.println("check " + " " + getEmail + "  " + getEmailValue + " = " + accountsValue);

                            checkedEmail = checkEmail(accountsValue, getEmailValue);
                        }
                        return;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }catch (Exception e){

        }
        return checkedEmail;
    }

    public boolean checkEmail(String accounts, String emailValue){

        FirebaseAuth mAuth = FirebaseAuth.getInstance();
        emailFromFirebase = mAuth.getCurrentUser().getEmail();

        System.out.println("Current Directory "+ accounts);

        if (emailFromFirebase.equals(emailValue)){
            //Data Fetch
            System.out.println("Emails Match: "+emailFromFirebase +" & "+ emailValue);
          String dummy= maintenanceFetchDatabase(accounts);

            return true;
        }else {
            System.out.println("Emails Does not Match: " + emailFromFirebase + " & " + emailValue);
            return false;

        }}

    public  String maintenanceFetchDatabase(String accounts) {
        maintenancefetch = maintenancefetch.child("Accounts").child(accounts).child("Maintenance").child(yearSpinnerfirst);
       maintenancefetch= maintenancefetch.child("2015");
        String abcd = "1234567";
        System.out.println("childadded");
        maintenancefetch.addValueEventListener(new ValueEventListener() {

            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                System.out.println("DataChanged");

                //monthValue = dataSnapshot.getValue(String.class);
                System.out.println(dataSnapshot.getChildrenCount());
                System.out.println(month + "'s Maintenance: " + monthValue);
                for (DataSnapshot monthSnapshot : dataSnapshot.getChildren()) {
                    for (DataSnapshot mSnapshot : monthSnapshot.getChildren()) {
                    System.out.println(mSnapshot.getKey());

                    month=mSnapshot.getKey();
                    monthValue =mSnapshot.getValue().toString();
                    //  month =  String.valueOf(monthSnapshot.getKey());
                    // monthValue= monthSnapshot.getValue(String.class);
                    Log.d("Month updated", "month: " + month); //log
                    // System.out.println(month);

                    //*  arrayMonth[i] = month;
                    //   arrayMonthValue[i] = monthValue;
                    // i++;
                    //*
                }   } updateValue(month, monthValue);

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getMessage());
            }
        });
        return abcd;
    }


    public void updateValue(String arrayMonth, String arrayMonthValue){
        ArrayList<String> arraymonth= new ArrayList<>();
        arraymonth.add(arrayMonth);
        System.out.println("Month: "+arraymonth);


        ArrayList<String> arraymonthvalue= new ArrayList<>();
        arraymonthvalue.add(arrayMonthValue);
        System.out.println("Month's Maintenance: "+arraymonthvalue);
    }
}
