package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.hms.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragment extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener{
    View view;
    Spinner monthSpinner;
    Spinner yearSpinner;
    Spinner flatnoSpinner;
    Spinner statusSpinner;
    Button submitadmin;

    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    String []flatnos= new String[]{"A101","A102","A103","B101","B102","B103","C101","C102","C103"};
    String [] bill_status= new String[]{"Not Paid","Paid"};
    public MaintenanceFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view=inflater.inflate(R.layout.fragment_maintenance, container, false);
       monthSpinner=(Spinner)view.findViewById(R.id.monthspinneradmin);
       yearSpinner = (Spinner)view.findViewById(R.id.yearspinneradmin);
       flatnoSpinner =(Spinner)view.findViewById(R.id.flatspinneradmin);
       statusSpinner =(Spinner) view.findViewById(R.id.statuspinneradmin);

       submitadmin=(Button)view.findViewById(R.id.submitadmin);

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);
        ArrayAdapter adapterflats = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,flatnos);
        ArrayAdapter adapterStatus = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,bill_status);
        monthSpinner.setAdapter(adapterMonths);
        yearSpinner.setAdapter(adapterYears);
        flatnoSpinner.setAdapter(adapterflats);
        statusSpinner.setAdapter(adapterStatus);
        monthSpinner.setOnItemSelectedListener(this);
        yearSpinner.setOnItemSelectedListener(this);
        flatnoSpinner.setOnItemSelectedListener(this);
        statusSpinner.setOnItemSelectedListener(this);

        submitadmin.setOnClickListener(this);

       return view;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {

    }


}
