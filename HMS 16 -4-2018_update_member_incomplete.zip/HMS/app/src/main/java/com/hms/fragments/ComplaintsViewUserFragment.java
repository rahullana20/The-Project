package com.hms.fragments;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplaintsViewUserFragment extends Fragment {

    FloatingActionButton plus;
    FragmentManager fragmentManager;

    public ComplaintsViewUserFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        View view = inflater.inflate(R.layout.fragment_complaints_view_user,container,false);
        plus = view.findViewById(R.id.plus);

        if (plus!=null)
        {
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Fragment fragment = new ComplaintsAddUserFragment();
                    fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();
                }
            });
        }return view;
    }
}
