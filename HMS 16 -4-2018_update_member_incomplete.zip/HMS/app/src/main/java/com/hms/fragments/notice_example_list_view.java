package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class notice_example_list_view extends Fragment {

    View view;
    FirebaseDatabase data;
    DatabaseReference ref;
    private ListView mUserlist, mess;
    private ArrayList<String> title = new ArrayList<>();
    private ArrayList<String> message = new ArrayList<>();

    public notice_example_list_view() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_notice_example, container, false);

        try{
        ref = FirebaseDatabase.getInstance().getReference("Notice").child("3MpXje3ULfa8aBhyJbq0rGi0YMN2");
        mUserlist = view.findViewById(R.id.list);
        mess = view.findViewById(R.id.mess);

        final ArrayAdapter<String> arrayAdapterTitle = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,title);
        final ArrayAdapter<String> arrayAdapterMessage = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1,message);

        mUserlist.setAdapter(arrayAdapterTitle);
        mess.setAdapter(arrayAdapterMessage);


        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.getValue(String.class);
                title.add(value);

                String val = dataSnapshot.getKey();
                message.add(val);

                arrayAdapterTitle.notifyDataSetChanged();
                arrayAdapterMessage.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }catch (Exception e){}

        return view;
    }

}
