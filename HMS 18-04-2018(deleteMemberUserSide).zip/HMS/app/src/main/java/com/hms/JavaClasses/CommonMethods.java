package com.hms.JavaClasses;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.preference.PreferenceManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.LinearLayoutCompat;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.Transformation;
import android.view.animation.TranslateAnimation;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;

import com.hms.R;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Created by kundan.singh on 9/12/2016.
 */
public class CommonMethods {
    private static ProgressDialog dialog;
    //cool
    public static boolean isOnline(Context c) {
        try {
            boolean haveConnectedWifi = false;
            boolean haveConnectedMobile = false;

            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            // connected to the internet
            if (activeNetwork != null)
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {

                    // connected to wifi
                    haveConnectedWifi = true;

                } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                    // connected to the mobile provider's data plan
                    haveConnectedMobile = true;
                }
            return haveConnectedWifi || haveConnectedMobile;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * Shows the progress UI and hides the login form.
     */
    public static void showProgress(Context context, final View mRootView, final ProgressBar mProgressView, final boolean show) {
        // On Honeycomb MR2 we have the ViewPropertyAnimator APIs, which allow
        // for very easy animations. If available, use these APIs to fade-in
        // the progress spinner.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB_MR2) {
            int shortAnimTime = context.getResources().getInteger(android.R.integer.config_shortAnimTime);

            mRootView.setVisibility(show ? View.GONE : View.VISIBLE);
            mRootView.animate().setDuration(shortAnimTime).alpha(
                    show ? 0 : 1).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mRootView.setVisibility(show ? View.GONE : View.VISIBLE);
                }
            });

            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mProgressView.animate().setDuration(shortAnimTime).alpha(
                    show ? 1 : 0).setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
                }
            });
        } else {
            // The ViewPropertyAnimator APIs are not available, so simply show
            // and hide the relevant UI components.
            mProgressView.setVisibility(show ? View.VISIBLE : View.GONE);
            mRootView.setVisibility(show ? View.GONE : View.VISIBLE);
        }
    }

    public static void showDialog(Context context, String message) {
        if (dialog == null) {
            dialog = new ProgressDialog(context);
        }
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        if (message != null) {
            dialog.setMessage(message);
        } else {
            dialog.setMessage("Loading...");
        }
        dialog.setIndeterminate(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.show();
    }

    public static void ShowAlertDialog(Context context, String message) {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
        alertDialog.setTitle("MESSAGE");
        alertDialog.setMessage(message);
           /* alertDialog.setNegativeButton( "CONTINUE TO SKIP", new DialogInterface.OnClickListener()
                    {
                          public void onClick( DialogInterface dialog, int which )
                          {
                                openDashBoard();
                          }
                    }
            );*/
        alertDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }
        );
        AlertDialog dialog = alertDialog.create();
        dialog.show();
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(context, R.color.colorPrimaryDark));
    }

     /* public static void ShowAlertDialog( Context context, String message, final AlertButtonListerner listerner )
      {
            AlertDialog.Builder alertDialog = new AlertDialog.Builder( context );
            alertDialog.setTitle( "MESSAGE" );
            alertDialog.setMessage( message );
           *//* alertDialog.setNegativeButton( "CONTINUE TO SKIP", new DialogInterface.OnClickListener()
                    {
                          public void onClick( DialogInterface dialog, int which )
                          {
                                openDashBoard();
                          }
                    }
            );*//*
            alertDialog.setPositiveButton( "OK", new DialogInterface.OnClickListener()
                        {
                              public void onClick( DialogInterface dialog, int which )
                              {
                                    dialog.dismiss();
                                    listerner.action();
                              }
                        }
            );
            AlertDialog dialog = alertDialog.create();
            dialog.show();
            dialog.getButton( AlertDialog.BUTTON_POSITIVE ).setTextColor( ContextCompat.getColor( context, R.color.colorPrimaryDark ) );
      }*/

    public static void hideDialog() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
            dialog = null;
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public static void setStatusBarColor(Activity activity, int colorID) {
        Window window = activity.getWindow();

        // clear FLAG_TRANSLUCENT_STATUS flag:
        window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);

        // add FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS flag to the window
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        // finally change the color
        window.setStatusBarColor(ContextCompat.getColor(activity, colorID));
    }

    public static void showView(Context context, final View view, int animationID) {
        if (view.getVisibility() == View.VISIBLE) {
            return;
        }

        // load the animation
        Animation animation = AnimationUtils.loadAnimation(context, animationID);
        animation.setDuration(300);

        // set animation listener
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setVisibility(View.VISIBLE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        view.startAnimation(animation);
    }

    public static void hideView(Context context, final View view, int animationID, final boolean makeGONE) {
        if (view.getVisibility() != View.VISIBLE) {
            return;
        }

        // load the animation
        Animation animation = AnimationUtils.loadAnimation(context, animationID);
        animation.setDuration(300);

        // set animation listener
        animation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                if (makeGONE) {
                    view.setVisibility(View.GONE);
                } else {
                    view.setVisibility(View.INVISIBLE);
                }
            }

            @Override
            public void onAnimationRepeat(Animation animation) {
            }
        });
        view.startAnimation(animation);
    }

    public static void expandView(final View v, int duration) {
        v.measure(LinearLayoutCompat.LayoutParams.MATCH_PARENT, LinearLayoutCompat.LayoutParams.WRAP_CONTENT);
        final int targetHeight = v.getMeasuredHeight();

        // Older versions of android (pre API 21) cancel animations for views with a height of 0.
        v.getLayoutParams().height = 1;
        v.setVisibility(View.VISIBLE);
        Animation a = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                v.getLayoutParams().height = interpolatedTime == 1 ? LinearLayoutCompat.LayoutParams.WRAP_CONTENT : (int) (targetHeight * interpolatedTime);
                v.requestLayout();
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        // 1dp/ms
        // a.setDuration((int)(targetHeight / v.getContext().getResources().getDisplayMetrics().density));
        if (duration != -1) {
            a.setDuration(duration);
        } else {
            a.setDuration(1000);
        }
        a.setInterpolator(new AccelerateDecelerateInterpolator());
        v.startAnimation(a);
    }

    public static void collapseView(final View v, int duration) {
        final int initialHeight = v.getMeasuredHeight();

        Animation a = new Animation() {
            @Override
            protected void applyTransformation(float interpolatedTime, Transformation t) {
                if (interpolatedTime == 1) {
                    v.setVisibility(View.GONE);
                } else {
                    v.getLayoutParams().height = initialHeight - (int) (initialHeight * interpolatedTime);
                    v.requestLayout();
                }
            }

            @Override
            public boolean willChangeBounds() {
                return true;
            }
        };

        if (duration != -1) {
            a.setDuration(duration);
        } else {
            // 1dp/ms
            a.setDuration((int) (initialHeight / v.getContext().getResources().getDisplayMetrics().density));
        }

        v.startAnimation(a);
    }

    public static String getStringImage(Bitmap bmp) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 100, baos);
        byte[] imageBytes = baos.toByteArray();
        String encodedImage = Base64.encodeToString(imageBytes, Base64.DEFAULT);
        return encodedImage;
    }

    public static Bitmap getBitmap(String imageFilePath) {
        BitmapFactory.Options bmpFactoryOptions = new BitmapFactory.Options();
        bmpFactoryOptions.inJustDecodeBounds = true;
        bmpFactoryOptions.inSampleSize = 2;
        bmpFactoryOptions.inJustDecodeBounds = false;
        Bitmap bmp = BitmapFactory.decodeFile(imageFilePath, bmpFactoryOptions);
        return bmp;
    }

    /**
     * This method converts dp unit to equivalent pixels, depending on device density.
     *
     * @param dp      A value in dp (density independent pixels) unit. Which we need to convert into
     *                pixels
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent px equivalent to dp depending on device density
     */
    public static float convertDpToPixel(float dp, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return px;
    }

    /**
     * This method converts device specific pixels to density independent pixels.
     *
     * @param px      A value in px (pixels) unit. Which we need to convert into db
     * @param context Context to get resources and device specific display metrics
     * @return A float value to represent dp equivalent to px value
     */
    public static float convertPixelsToDp(float px, Context context) {
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / ((float) metrics.densityDpi / DisplayMetrics.DENSITY_DEFAULT);
        return dp;
    }

    private void moveViewToScreenCenter(Activity activity, View view, View root) {
        DisplayMetrics dm = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getMetrics(dm);
        int statusBarOffset = dm.heightPixels - root.getMeasuredHeight();

        int originalPos[] = new int[2];
        view.getLocationOnScreen(originalPos);

        int xDest = dm.widthPixels / 2;
        xDest -= (view.getMeasuredWidth() / 2);
        int yDest = dm.heightPixels / 2 - (view.getMeasuredHeight() / 2) - statusBarOffset;

        TranslateAnimation anim = new TranslateAnimation(0, xDest - originalPos[0], 0, yDest - originalPos[1]);
        // anim.setRepeatCount( Animation.INFINITE );
        // anim.setRepeatMode( Animation.REVERSE );
        anim.setInterpolator(new AccelerateDecelerateInterpolator());
        anim.setDuration(1000);
        anim.setFillAfter(true);
        view.startAnimation(anim);
    }

    public static Object performGet(Context context, String baseURL, Map<String, String> headers) {

        //String url = "http://localhost:9090/restro/Test?data=clos";
        final String SET_COOKIE = "Set-Cookie";
        URL obj;
        HttpURLConnection con = null;
        JSONObject cookies = new JSONObject();

        try {
            obj = new URL(baseURL);
            con = (HttpURLConnection) obj.openConnection();


            // optional default is GET
            con.setRequestMethod("GET");

            //add request header
            //con.setRequestProperty("User-Agent", "Mozilla/5.0");
            //con.setRequestProperty("Accept-Encoding","identity");

            for (Map.Entry entry : headers.entrySet()) {
                Log.i("req headerName is ", entry.getKey().toString());
                con.setRequestProperty(entry.getKey().toString(), entry.getValue().toString());
            }
            int responseCode = con.getResponseCode();

            Log.i("URL : ", baseURL + "");
            Log.i("Response Code : ", responseCode + "");

            String headerName = null;
            for (int i = 1; (headerName = con.getHeaderFieldKey(i)) != null; i++) {
                Log.i("headerName is ", headerName);
                if (headerName.equalsIgnoreCase(SET_COOKIE)) {

                    //headers.put("Cookie", con.getHeaderField(i));
                    cookies.put("Cookie", con.getHeaderField(i));


                    CommonMethods.savePreference(context, "Cookies", cookies.toString(), Constants.STRING);

                    Log.i("Cookie", headers.get("Cookie"));
                    return cookies.toString();
                }
            }
            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result

            Log.i("Response ", response.toString());
            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }

    public static String performPost(Context context, String baseURL, Map<String, String> headers, String requestData) {

        //String url = "http://localhost:9090/restro/Test?data=clos";
        final String SET_COOKIE = "Set-Cookie";
        URL obj;
        HttpURLConnection con = null;
        try {
            obj = new URL(baseURL);
            con = (HttpURLConnection) obj.openConnection();


            // optional default is POST
            con.setRequestMethod("POST");
            con.setConnectTimeout(10000);
            //add request header
            con.setRequestProperty("User-Agent", "Mozilla/5.0");

            for (Map.Entry entry : headers.entrySet()) {
                con.setRequestProperty(entry.getKey().toString(), entry.getValue().toString());
            }



            Log.i("Request Data", requestData + "");
            //System.out.print("Request Data " + requestData);
            if (requestData != null) {
                OutputStream os = con.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(requestData);
                writer.flush();
                writer.close();
                os.close();
            }
            String headerName = null;
            for (int i = 1; (headerName = con.getHeaderFieldKey(i)) != null; i++) {
                if (headerName.equalsIgnoreCase(SET_COOKIE)) {

                    headers.put("Cookie", con.getHeaderField(i));
                }
            }
            int responseCode = con.getResponseCode();

            Log.i("URL : ", baseURL + "");
            Log.i("Response Code : ", responseCode + "");

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();

            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            //print result

            Log.i("Response ", response.toString());
            return response.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;

    }

   /* public static String performPost(String baseURL, String requestData, String accept, String contentType) {
           *//* boolean inDebuggMode = true;
            if ( inDebuggMode )
            {
                  JSONObject jsonObject = null;
                  try
                  {
                        jsonObject = new JSONObject();
                        jsonObject.put( Constants.KEY_STATUS,Constants.SUCCESS );
                        jsonObject.put( Constants.KEY_VALUE,"This is dummy success message" );
                  }
                  catch ( JSONException e )
                  {
                        e.printStackTrace();
                  }
                  return jsonObject.toString();
            }*//*

        URL url;
        HttpsURLConnection conn = null;
        try {


            url = new URL(baseURL);
            conn = (HttpsURLConnection) url.openConnection();
            conn.setReadTimeout(10000);
            conn.setConnectTimeout(15000);
            conn.setRequestMethod("POST");
            conn.setDoInput(true);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", contentType);
            conn.setRequestProperty("Accept", accept);

                  *//*Uri.Builder builder = new Uri.Builder()
                              .appendQueryParameter( "method", method )
                              .appendQueryParameter( "data", dataJsonString );
                  String query = builder.build().getEncodedQuery();*//*


            if (requestData != null) {
                OutputStream os = conn.getOutputStream();
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                writer.write(requestData);
                writer.flush();
                writer.close();
                os.close();
            }


            return readStream(conn.getInputStream());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (ProtocolException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (conn != null) {
                conn.disconnect();
            }
            return null;
        }
    }*/

    private static String readStream(InputStream is) throws IOException {
        final BufferedReader reader = new BufferedReader(new InputStreamReader(is, Charset.forName("US-ASCII")));
        StringBuilder total = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            total.append(line);
        }
        if (reader != null) {
            reader.close();
        }
        return total.toString();
    }

    public static void savePreference(Context context, String PREFS_KEY, String value, String ValueType) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;
        settings = PreferenceManager.getDefaultSharedPreferences(context); //1
        editor = settings.edit(); //2

        switch (ValueType) {
            case Constants.STRING:
                editor.putString(PREFS_KEY, value); //3
                break;
            case Constants.INT:
                editor.putInt(PREFS_KEY, Integer.parseInt(value)); //3
                break;
            case Constants.FLOAT:
                editor.putFloat(PREFS_KEY, Float.parseFloat(value)); //3
                break;
            case Constants.LONG:
                editor.putLong(PREFS_KEY, Long.parseLong(value)); //3
                break;
            case Constants.BOOLEAN:
                editor.putBoolean(PREFS_KEY, Boolean.parseBoolean(value)); //3
                break;
        }
        editor.apply(); //4
    }

    public static Object getPreferenceValue(Context context, String PREFS_KEY, String ValueType) {
        SharedPreferences settings;
        Object value = null;
        settings = PreferenceManager.getDefaultSharedPreferences(context); //1

        switch (ValueType) {
            case Constants.STRING:
                value = settings.getString(PREFS_KEY, null); //2
                break;
            case Constants.INT:
                value = settings.getInt(PREFS_KEY, -1); //2
                break;
            case Constants.FLOAT:
                value = settings.getFloat(PREFS_KEY, -1); //2
                break;
            case Constants.LONG:
                value = settings.getLong(PREFS_KEY, -1); //2
                break;
            case Constants.BOOLEAN:
                value = settings.getBoolean(PREFS_KEY, false); //2
                break;
        }

        return value;
    }

    public static void removePreference(Context context, String PREFS_KEY) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;
        settings = PreferenceManager.getDefaultSharedPreferences(context);
        editor = settings.edit();

        editor.remove(PREFS_KEY);
        editor.apply();
    }

    public static void clearPreference(Context context) {
        SharedPreferences settings;
        SharedPreferences.Editor editor;

        settings = PreferenceManager.getDefaultSharedPreferences(context);
        editor = settings.edit();

        editor.clear();
        editor.commit();
    }

    public static Boolean matchRegex(String checkThis, String... regexPatterns) {
        for (String thisRegex : regexPatterns) {
            if (!Pattern.matches(thisRegex, checkThis.trim())) {
                return false;
            }
        }
        return true;
    }

    public static void showKeyboard(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.showSoftInput(view, InputMethodManager.SHOW_FORCED);
    }

    public static void hideKeyboard(Context context, View view) {
        InputMethodManager imm = (InputMethodManager) context.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }
}
