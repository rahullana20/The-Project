package com.hms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

   AutoCompleteTextView name;
    AutoCompleteTextView username;
    EditText password;
    AutoCompleteTextView plot_no;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button sign_up;



    TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        loginLink = (TextView) findViewById(R.id.labeltextview);
        name = (AutoCompleteTextView) findViewById(R.id.fullname);
        username = (AutoCompleteTextView) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        plot_no = (AutoCompleteTextView) findViewById(R.id.plotno);
        number_of_members = (AutoCompleteTextView) findViewById(R.id.totalmembers);
        contact_no = (AutoCompleteTextView) findViewById(R.id.contactno);
        swimming_pool = (CheckBox) findViewById(R.id.swimmingpoolcb);
        sports_club = (CheckBox) findViewById(R.id.sportsclubcb);
        aadhar_card_no = (AutoCompleteTextView) findViewById(R.id.aadharno);
        sign_up = (Button) findViewById(R.id.sign_up_button);
        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                RegisterActivity.this.startActivity(loginIntent);
            }
        });


    }
}


