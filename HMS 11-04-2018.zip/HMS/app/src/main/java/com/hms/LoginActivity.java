package com.hms;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.activities.MainActivity;
import com.hms.activities.RegisterActivity;

import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.net.UnknownHostException;
import java.util.HashMap;
import java.util.Map;

public class LoginActivity extends AppCompatActivity {

    AutoCompleteTextView username;
    EditText password;
    Button login;
    String DataParseUrl = "http://localhost/android_connect/Login.php";
    String uNameToSend, passwordToSend;
    String dummyName = "rahul";
    String dummyPwd = "rahul12";
    String dummyadmin = "admin";
    String dummyapass = "admin12";
    TextView registerLink;
    FirebaseDatabase database;
    DatabaseReference ref;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        database = FirebaseDatabase.getInstance();
        ref = database.getReference("Accounts");

        // To know whether the user has already logged in or not

        if (CommonMethods.getPreferenceValue(this, "uname", Constants.STRING) != null) {
            if (CommonMethods.getPreferenceValue(this, "uname", Constants.STRING).equals(ref.child("Admin/UserName"))) {
                //Toast.makeText(LoginActivity.this, "Response is-" + s, Toast.LENGTH_SHORT).show();
                //CommonMethods.savePreference(LoginActivity.this,"uname",dummyName,Constants.STRING);
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            }

            if (CommonMethods.getPreferenceValue(this, "uname", Constants.STRING).equals(dummyadmin)) {
                //Toast.makeText(LoginActivity.this, "Response is-" + s, Toast.LENGTH_SHORT).show();
                //CommonMethods.savePreference(LoginActivity.this,"uname",dummyadmin,Constants.STRING);
                Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
                startActivity(intent);
                finish();

            }
        }

        registerLink = (TextView) findViewById(R.id.textView);
        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.sign_in_button);
        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registerIntent = new Intent(LoginActivity.this, RegisterActivity.class);
                LoginActivity.this.startActivity(registerIntent);
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uNameToSend = username.getText().toString();
                passwordToSend = password.getText().toString();

                boolean errorFlag = false;


                if (TextUtils.isEmpty(username.getText().toString())) {

                    username.setError("Please enter username");

                    errorFlag = true;

                }


                if (TextUtils.isEmpty(password.getText().toString())) {

                    password.setError("Please enter password");

                    /*Drawable dr = getResources().getDrawable(R.drawable.error);

                    //add an error icon to yur drawable files

                    dr.setBounds(0, 0, dr.getIntrinsicWidth(), dr.getIntrinsicHeight());



                    password.setCompoundDrawables(null,null,dr,null);*/

                    errorFlag = true;

                }



                /*if (TextUtils.isEmpty(editTextWebsite.getText().toString())) {

                    editTextWebsite.setError("Please enter website");

                    errorFlag = true;

                }*/


                //SendDataToServer(GetName, GetEmail, GetWebsite);

                if (!errorFlag) {

                    if (isOnline()) {

                        GetDataFromEditText();

                        new sendDataToServer().execute();

                    } else {

                        /*Snackbar snackbar = Snackbar

                                .make(getView(), "Please check your connection", Snackbar.LENGTH_LONG);

                        snackbar.show();*/

                        Toast.makeText(LoginActivity.this, "Please check your connection", Toast.LENGTH_SHORT).show();

                    }

                }

                //new sendDataToServer().execute();

            }
        });
    }

    private void GetDataFromEditText() {

        uNameToSend = username.getText().toString();

        passwordToSend = password.getText().toString();

        //GetWebsite = editTextWebsite.getText().toString();

    }

    public class sendDataToServer extends AsyncTask<String, Void, String> {


        @Override

        protected String doInBackground(String... strings) {

            try {


                Map<String, String> dataToSend = new HashMap<>();

                dataToSend.put("username", uNameToSend);

                dataToSend.put("password", passwordToSend);

                //dataToSend.put("website", GetWebsite);


                String encodedStr = getEncodedData(dataToSend);


                //Converting address string to url

                URL url = new URL(DataParseUrl);

                //Log.i("URL", "url is " + url);

                //Opening the connection

                HttpURLConnection con = (HttpURLConnection) url.openConnection();

                //Post Method

                con.setRequestMethod("POST");

                con.setDoOutput(true);


                int read;
                String result;
                try (OutputStreamWriter writer = new OutputStreamWriter(con.getOutputStream())) {

                    writer.write(encodedStr);


                    writer.flush();
                }


                result = "";

                try (InputStream inputStream = con.getInputStream()) {

                    while ((read = inputStream.read()) != -1) {

                        result += (char) read;

                    }
                }

                //Log.i("result", "result is " + result);


                return result;


            } catch (UnknownHostException e) {

                Toast.makeText(LoginActivity.this, "Failed to connect to Internet", Toast.LENGTH_SHORT).show();

            } catch (Exception e) {

                e.printStackTrace();

            }


            return null;


        }


        @Override

        protected void onPostExecute(String s) {

            super.onPostExecute(s);

            if (uNameToSend.equals(dummyName) && passwordToSend.equals(dummyPwd)) {
                //Toast.makeText(LoginActivity.this, "Response is-" + s, Toast.LENGTH_SHORT).show();
                CommonMethods.savePreference(LoginActivity.this, "uname", dummyName, Constants.STRING);
                Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                startActivity(intent);
                finish();
            } else if (uNameToSend.equals(dummyadmin) && passwordToSend.equals(dummyapass)) {
                //Toast.makeText(LoginActivity.this, "Response is-" + s, Toast.LENGTH_SHORT).show();
                CommonMethods.savePreference(LoginActivity.this, "uname", dummyadmin, Constants.STRING);
                Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
                startActivity(intent);
                finish();

            } else {
                Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
            }
        }
    }
    //Method to encode Data with URL
    public String getEncodedData(Map<String, String> dataToSend) {

        StringBuilder sb = new StringBuilder();

        for (String key : dataToSend.keySet()) {

            String value = null;

            try {
                value = URLEncoder.encode(dataToSend.get(key), "UTF-8");
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }

            if (sb.length() > 0)
                sb.append("&");

            sb.append(key + "=" + value);

        }

        return sb.toString();

    }
    public boolean isOnline() {
        try {
            boolean haveConnectedWifi = false;
            boolean haveConnectedMobile = false;

            ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            if (activeNetwork != null) {
                // connected to the internet
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {

                    // connected to wifi
                    haveConnectedWifi = true;

                } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                    // connected to the mobile provider's data plan
                    haveConnectedMobile = true;
                }
            }
            return haveConnectedWifi || haveConnectedMobile;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
