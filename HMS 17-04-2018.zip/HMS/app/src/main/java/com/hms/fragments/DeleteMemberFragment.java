package com.hms.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.google.android.gms.tasks.Task;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;


public class DeleteMemberFragment extends Fragment implements AdapterView.OnItemSelectedListener {
    View view;
    Spinner deleteSpinner;
    Button delete;

    DatabaseReference ref;
    List<String> names = new ArrayList<>();
    ArrayList<String> mKeys = new ArrayList<>();

    String itemSelected, value;

    public DeleteMemberFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_delete_member, container, false);

        deleteSpinner= view.findViewById(R.id.deletespinner);
        delete= view.findViewById(R.id.deletebutton);

        ref = FirebaseDatabase.getInstance().getReference().child("Accounts");

        final ArrayAdapter<String> adapterDeleteMember = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item,names);
        adapterDeleteMember.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        deleteSpinner.setAdapter(adapterDeleteMember);

        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                value = String.valueOf(dataSnapshot.getKey());
                names.add(value);

                String key = dataSnapshot.getKey();
                mKeys.add(key);

                adapterDeleteMember.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                String val = dataSnapshot.getValue(String.class);
                String keyy = dataSnapshot.getKey();

                int index = mKeys.indexOf(keyy);
                names.set(index, val);

                adapterDeleteMember.notifyDataSetChanged();
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ref.child(value).removeValue();
            }
        });

        return view;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
