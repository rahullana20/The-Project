package com.hms.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.hms.JavaClasses.CommonMethods;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.Model.MenuModel;
import com.hms.R;
import com.hms.adapters.DrawerItemCustomAdapter;
import com.hms.fragments.ComplaintsViewAdminFragment;
import com.hms.fragments.DeleteMemberFragment;
import com.hms.fragments.MaintenanceFragment;
import com.hms.fragments.ReportsFragment;
import com.hms.fragments.UpdateMemberFragment;
import com.hms.fragments.NoticeFragment;

public class AdminActivity extends AppCompatActivity {

    private DrawerLayout mDrawerLayout;
    private ListView menuList;
    private String[] mNavigationDrawerItemTitles;
	DatabaseReference ref;
	
	String username;
    TextView navUserName;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        mNavigationDrawerItemTitles= getResources().getStringArray(R.array.admin_navigation_drawer_items_array);
        menuList =  findViewById(R.id.menu_list);
        mDrawerLayout = findViewById(R.id.drawer_layout);
		//ref = FirebaseDatabase.getReference().child("Accounts").child(uid);

        NavigationView navigationView = findViewById(R.id.nav_view);
        if (navigationView != null){
            setupDrawerContent(navigationView);
        }
        View header = navigationView.getHeaderView(0);

		username = mAuth.getCurrentUser().getEmail().toString();
		
        navUserName = header.findViewById(R.id.nav_username);
        navUserName.setText(username);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Set Notice Fragment on start up
        Fragment fragment = new NoticeFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();

        //Menu logo - 3 lines
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        MenuModel[] drawerItem = new MenuModel[6];

        drawerItem[0] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Notice");
        drawerItem[1] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Maintenance");
        drawerItem[2] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Complaints");
        drawerItem[3] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Update Member");
        drawerItem[4] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Reports");
        drawerItem[5] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Logout");
        //Adapter to pass in listview
        DrawerItemCustomAdapter adapter = new DrawerItemCustomAdapter(this, R.layout.list_view_item_row, drawerItem);
        menuList.setAdapter(adapter);
        menuList.setOnItemClickListener(new AdminActivity.DrawerItemClickListener());
    }

    private class DrawerItemClickListener implements ListView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            selectItem(position);
        }
    }

    private void selectItem(int position) {
        Fragment fragment = null;

        switch (position) {
            case 0:
                fragment = new NoticeFragment();
                break;
            case 1:
                fragment = new MaintenanceFragment();
                break;
            case 2:
                fragment = new ComplaintsViewAdminFragment();
                break;
            case 3:
                fragment = new UpdateMemberFragment();
                break;
            case 4:
                fragment = new DeleteMemberFragment();
                break;
            case 5:
                new AlertDialog.Builder(AdminActivity.this)
                        .setTitle("Logout")
                        .setMessage("Do you really want to Logout?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                CommonMethods.clearPreference(AdminActivity.this);
                                mAuth.signOut();
                                AdminActivity.this.finish();
                                startActivity(new Intent(AdminActivity.this, Login.class));
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
                break;
            default:
                break;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();

            menuList.setItemChecked(position, true);
            menuList.setSelection(position);
            setTitle(mNavigationDrawerItemTitles[position]);
            mDrawerLayout.closeDrawer(GravityCompat.START);

        } else {
            Log.e("AdminActivity", "Error in creating fragment");
        }
    }

    private void setupDrawerContent(NavigationView navigationView) {

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        menuItem.setChecked(true);
                        mDrawerLayout.closeDrawers();
                        return true;
                    }

                });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}