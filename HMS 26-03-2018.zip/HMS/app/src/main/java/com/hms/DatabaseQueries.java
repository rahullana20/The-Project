package com.hms;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Deepak jain on 23-03-2018.
 */

public class DatabaseQueries {

    public static void updateRegister(String name,String emailID, String pass,String plot,String countmembers,String contact,String aadhar,String checkSwim,String checkSports){

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference query = database.getReference("Accounts");

        query.child(name);
        query.child(name).child("EmailId").setValue(emailID);
        query.child(name).child("Password").setValue(pass);
        query.child(name).child("PlotNumber").setValue(plot);
        query.child(name).child("TotalNumberOfMembers").setValue(countmembers);
        query.child(name).child("ContactNumber").setValue(contact);
        query.child(name).child("Aadhar").setValue(aadhar);
        query.child(name).child("SwimmingPool").setValue(checkSwim);
        query.child(name).child("SportsClub").setValue(checkSports);
        query.child(name).child("Maintenance");
        query.child(name).child("Tenants");
        query.child(name).child("Parking");
        query.child(name).child("Complaints");
        query.child(name).child("Notice");
    }
}
