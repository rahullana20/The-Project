package com.hms;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

/**
 * Created by Deepak jain on 22-03-2018.
 */

public class Activity extends AppCompatActivity {

    EditText userName, userPassw;
    Button submit;
    FirebaseDatabase database;
    DatabaseReference myRef;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);

        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("User");

        userName = (EditText)findViewById(R.id.nameUser);
        userPassw = (EditText)findViewById(R.id.userPassword);
        submit = (Button) findViewById(R.id.Submit123);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dataUploadName = userName.getText().toString();
                String dataUploadPass = userPassw.getText().toString();

                myRef.child("Admin").child("Login").setValue(dataUploadName);
                myRef.child("Admin").child("Password").setValue(dataUploadPass);
            }
        });
    }
}
