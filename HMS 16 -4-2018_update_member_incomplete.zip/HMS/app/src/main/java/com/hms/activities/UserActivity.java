package com.hms.activities;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.hms.CommonMethods;
import com.hms.Constants;
import com.hms.adapters.DrawerItemCustomAdapter;
import com.hms.MenuModel;
import com.hms.R;
import com.hms.fragments.ComplaintsViewUserFragment;
import com.hms.fragments.MaintenanceFragment;
import com.hms.fragments.MaintenanceFragmentUser;
import com.hms.fragments.NoticeFragment;
import com.hms.fragments.NoticeUserFragment;

public class UserActivity extends AppCompatActivity{

    private DrawerLayout mDrawerLayout;
    private ListView menuList;
    private String[] mNavigationDrawerItemTitles;
    TextView navUserName;

    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        mNavigationDrawerItemTitles= getResources().getStringArray(R.array.navigation_drawer_items_array);
        menuList =  findViewById(R.id.menu_list);
        mDrawerLayout = findViewById(R.id.drawer_layout);

        NavigationView navigationView = findViewById(R.id.nav_view);
        if (navigationView != null){
            setupDrawerContent(navigationView);
        }
        View header = navigationView.getHeaderView(0);

        navUserName = header.findViewById(R.id.nav_username);
        navUserName.setText(String.valueOf(CommonMethods.getPreferenceValue(UserActivity.this,"uname", Constants.STRING)));
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Set Notice Fragment on start up
        Fragment fragment = new NoticeUserFragment();
        FragmentManager fragmentManager = getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();

        //Menu logo - 3 lines
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, mDrawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        mDrawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        MenuModel[] drawerItem = new MenuModel[4];

        drawerItem[0] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Notice");
        drawerItem[1] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Maintenance");
        drawerItem[2] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Complaints");
        drawerItem[3] = new MenuModel(R.drawable.ic_announcement_black_24dp, "Logout");

        //Adapter to pass in listview
        DrawerItemCustomAdapter adapter = new DrawerItemCustomAdapter(this, R.layout.list_view_item_row, drawerItem);
        menuList.setAdapter(adapter);
        menuList.setOnItemClickListener(new DrawerItemClickListener());


    }



    private class DrawerItemClickListener implements ListView.OnItemClickListener {

        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            selectItem(position);
        }

    }

    //
    private void selectItem(int position) {

        Fragment fragment = null;

        switch (position) {
            case 0:
                fragment = new NoticeUserFragment();
                break;
            case 1:
                fragment = new MaintenanceFragmentUser();
                break;
            case 2:
                fragment = new ComplaintsViewUserFragment();
                break;
            case 3:
                new AlertDialog.Builder(UserActivity.this)
                        .setTitle("Logout")
                        .setMessage("Do you really want to Logout?")
                        .setIcon(android.R.drawable.ic_dialog_alert)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int whichButton) {
                                mAuth.signOut();
                                UserActivity.this.finish();
                                startActivity(new Intent(UserActivity.this, Login.class));

                                //NotificationManager notificationManager = (NotificationManager) UserActivity.this.getSystemService(Context.NOTIFICATION_SERVICE);
                                //notificationManager.cancelAll();
                                //Toast.makeText(UserActivity.this, "Yaay", Toast.LENGTH_SHORT).show();
                            }
                        })
                        .setNegativeButton(android.R.string.no, null).show();
                break;
            default:
                break;
        }

        if (fragment != null) {
            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();

            menuList.setItemChecked(position, true);
            menuList.setSelection(position);
            setTitle(mNavigationDrawerItemTitles[position]);
            mDrawerLayout.closeDrawer(GravityCompat.START);

        } else {
            Log.e("UserActivity", "Error in creating fragment");
        }
    }

    private void setupDrawerContent(NavigationView navigationView) {

        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {
                        menuItem.setChecked(true);
                        mDrawerLayout.closeDrawers();

                        return true;

                    }

                });

    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
}
