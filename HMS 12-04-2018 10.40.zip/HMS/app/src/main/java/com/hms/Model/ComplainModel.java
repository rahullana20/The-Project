package com.hms.Model;

public class ComplainModel {
    private String date;
    private String data;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getData() {
        return data;
    }

    public void setData(String quote) {
        this.data = quote;
    }
}
