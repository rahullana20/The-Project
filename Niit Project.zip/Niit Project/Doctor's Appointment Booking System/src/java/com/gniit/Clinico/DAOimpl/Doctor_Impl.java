/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAOimpl;

import DB_Connection.DBconnection;
import com.gniit.Clinico.DoctorDAO.Doctor_Interface;
import com.gniit.Clinico.Entity.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Namrata
 */
public class Doctor_Impl implements Doctor_Interface{

   
    public int adddoctor(Doctor doctor) {
        Connection con=DBconnection.getConnection();
    
  
        int count=0;
       
        try {
             String query="insert into Doctors(DoctorId,dName,dSpecialist,dEmailId,dContactNo) values(?,?,?,?,?)";
             
      PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,doctor.getDoctor_ID());
            pst.setString(2,doctor.getName()); 
            pst.setString(3,doctor.getSpecialist());
              pst.setString(4,doctor.getEmail_ID());
                pst.setInt(5,doctor.getContact_No());
                
            count = pst.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Impl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
 
        return count;
    }

    @Override
    public int deleteDoctor(int Doctor_ID) {
        int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Doctors where DoctorId=?");
            preparedStatement.setInt(1,Doctor_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Impl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
        
        
        
    }

    @Override
    public List<Doctor> getDoctors() {
        List<Doctor> doctorList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Doctors");
            ResultSet rs = preparedStatement.executeQuery();
            doctorList = new ArrayList<Doctor>();
            if(rs!=null){
               
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String specialist = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                  
                    Doctor doctor = new Doctor(id,name,specialist,emailid,contactno);
                    doctorList.add(doctor);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Impl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return doctorList;

        
      
    }

    @Override
    public Doctor getDoctorByID(int Doctor_ID) {
        List<Doctor> doctorList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Doctors where DoctorId=?");
            preparedStatement.setInt(1, Doctor_ID);
            ResultSet rs = preparedStatement.executeQuery();
           doctorList = new ArrayList<Doctor>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String specialist = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                
                    Doctor doctor = new Doctor(id,name,specialist,emailid,contactno);
                    doctorList.add(doctor);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Impl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(doctorList.size()>0) return doctorList.get(0);
     else return null;
        
    }

    @Override
    public int updateDoctor(int Doctor_ID, Doctor doctor) {
        int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Doctors set dName=?, dSpecialist=?, pEmailId=?, pContactNo=? where DoctorId=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,doctor.getDoctor_ID());
            pst.setString(2,doctor.getName());
            pst.setString(3,doctor.getSpecialist());
              pst.setString(4,doctor.getEmail_ID());
                pst.setInt(5,doctor.getContact_No());
                
                  count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(Doctor_Impl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
 
        
    }
    

