package com.hms;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {

    AutoCompleteTextView name;
    AutoCompleteTextView username;
    EditText password;
    AutoCompleteTextView plot_no;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button sign_up;

    TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        loginLink = (TextView) findViewById(R.id.labeltextview);
        name = (AutoCompleteTextView) findViewById(R.id.fullname);
        username = (AutoCompleteTextView) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
        plot_no = (AutoCompleteTextView) findViewById(R.id.plotno);
        number_of_members = (AutoCompleteTextView) findViewById(R.id.totalmembers);
        contact_no = (AutoCompleteTextView) findViewById(R.id.contactno);
        swimming_pool = (CheckBox) findViewById(R.id.swimmingpoolcb);
        sports_club = (CheckBox) findViewById(R.id.sportsclubcb);
        aadhar_card_no = (AutoCompleteTextView) findViewById(R.id.aadharno);
        sign_up = (Button) findViewById(R.id.sign_up_register);

        loginLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent loginIntent = new Intent(RegisterActivity.this, LoginActivity.class);
                RegisterActivity.this.startActivity(loginIntent);
            }
        });

        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //fetching data
                String Name = name.getText().toString();
                String userName = username.getText().toString();
                String pass = password.getText().toString();
                String plot = plot_no.getText().toString();
                String countmembers = number_of_members.getText().toString();
                String contact = contact_no.getText().toString();
                String aadhar = aadhar_card_no.getText().toString();

                String checkSwim, checkSports;

                if(swimming_pool.isChecked())
                {
                    checkSwim = "Yes";
                }
                else
                {
                    checkSwim = "No";
                }

                if(sports_club.isChecked())
                {
                    checkSports = "Yes";
                }
                else
                {
                    checkSports = "No";
                }

                DatabaseQueries dq = new DatabaseQueries();
                dq.updateRegister(Name,userName, pass, plot, countmembers, contact, aadhar, checkSwim, checkSports);

                name.getText().clear();
                username.getText().clear();
                password.getText().clear();
                plot_no.getText().clear();
            }
        });

    }
}


