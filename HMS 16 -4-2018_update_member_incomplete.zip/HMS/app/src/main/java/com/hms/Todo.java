package com.hms;

public class Todo {
    private String author;
    private String message;

    public Todo() {
        // empty default constructor, necessary for Firebase to be able to deserialize blog posts
    }

    public String getAuthor() {
        return author;
    }

    public String getMessage() {
        return message;
    }

}
