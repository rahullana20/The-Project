package com.hms.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hms.JavaClasses.CommonMethods;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplaintsAddUserFragment extends Fragment {

    EditText titleComplaint, messageComplaint;
    Button submit;
    View view;
    private ProgressDialog progressDialog;
    public ComplaintsAddUserFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Add a Complaint");

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_complaints_add_user, container, false);

        progressDialog = new ProgressDialog(getActivity());

        titleComplaint = (EditText) view.findViewById(R.id.complaintTitle);
        messageComplaint = (EditText) view.findViewById(R.id.complaintMessage);
        submit = view.findViewById(R.id.complaintSubmit);

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String title = titleComplaint.getText().toString().trim();
                final String message = messageComplaint.getText().toString().trim();

                if (TextUtils.isEmpty(title)) {
                    titleComplaint.setError("Enter a title");
                    return;
                }
                else if (TextUtils.isEmpty(message)) {
                    messageComplaint.setError("Enter a detailed description");
                    return;
                }

                if (CommonMethods.isOnline(getActivity())) {
                    progressDialog.setMessage("Adding a Complaint");
                    progressDialog.show();
                    DatabaseQueries dq = new DatabaseQueries();
                    boolean flag = dq.addComplaint(title,message);
                    if (flag == false){
                        Toast.makeText(getContext(), "Complaint Added Successfully!", Toast.LENGTH_SHORT).show();
                        titleComplaint.getText().clear();
                        messageComplaint.getText().clear();
                        titleComplaint.requestFocus();
                    }
                    else if(flag == true){
                        Toast.makeText(getContext(), "Complain not sent, Please try again!", Toast.LENGTH_SHORT).show();
                        titleComplaint.getText().clear();
                        messageComplaint.getText().clear();
                        titleComplaint.requestFocus();
                    }
                }else {
                    Toast.makeText(getContext(), "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }
                if(progressDialog.isShowing()){
                    progressDialog.dismiss();
                }
            }
        });
    }
}
