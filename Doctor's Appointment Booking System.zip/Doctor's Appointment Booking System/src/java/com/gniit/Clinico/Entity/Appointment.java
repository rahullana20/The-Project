/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Entity;

/**
 *
 * @author Namrata
 */
public class Appointment {
    int Appointment_id;
    int Patient_ID;
    int Doctor_ID;
    int Timing_Slot;

    public int getAppointment_id() {
        return Appointment_id;
    }

    public void setAppointment_id(int Appointment_id) {
        this.Appointment_id = Appointment_id;
    }

    public int getPatient_ID() {
        return Patient_ID;
    }

    public void setPatient_ID(int Patient_ID) {
        this.Patient_ID = Patient_ID;
    }

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public int getTiming_Slot() {
        return Timing_Slot;
    }

    public void setTiming_Slot(int Timing_Slot) {
        this.Timing_Slot = Timing_Slot;
    }
public Appointment(){}

    public Appointment(int aid, int pid,int did, int timingslot) {
        this.Appointment_id = aid;
        this.Patient_ID = pid;
         this.Doctor_ID = did;
        this.Timing_Slot = timingslot;
    
   
    }

     public Appointment(int pid,int did, int timingslot) {
      
        this.Patient_ID = pid;
         this.Doctor_ID = did;
        this.Timing_Slot = timingslot;
    
   
    }
}