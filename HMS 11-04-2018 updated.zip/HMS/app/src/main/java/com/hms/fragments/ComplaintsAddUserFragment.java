package com.hms.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hms.CommonMethods;
import com.hms.DatabaseQueries;
import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplaintsAddUserFragment extends Fragment {

    EditText titleComplaint, messageComplaint;
    Button submit;
    View view;
    private ProgressDialog progressDialog;

    public ComplaintsAddUserFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Add a Complaint");

        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_complaints_add_user, container, false);

        progressDialog = new ProgressDialog(getActivity());

        titleComplaint = (EditText) view.findViewById(R.id.complaintTitle);
        messageComplaint = (EditText) view.findViewById(R.id.complaintMessage);
        submit = view.findViewById(R.id.complaintSubmit);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String title = titleComplaint.getText().toString().trim();
                final String message = messageComplaint.getText().toString().trim();

                if (TextUtils.isEmpty(title)) {
                    Toast.makeText(getActivity(), "Name cannot be blank", Toast.LENGTH_LONG).show();
                    titleComplaint.setError("Enter name");
                }
                else if (TextUtils.isEmpty(message)) {
                    Toast.makeText(getActivity(), "Plot Number cannot be blank", Toast.LENGTH_LONG).show();
                    messageComplaint.setError("Enter plot number");
                }

                progressDialog.setMessage("Adding a Complaint");
                progressDialog.show();

                if (CommonMethods.isOnline(getActivity())) {
                    progressDialog.dismiss();
                    DatabaseQueries dq = new DatabaseQueries();
                    dq.addComplaint(title,message);
                }
            }
        });
        return view;
    }
}
