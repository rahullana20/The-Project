package com.hms.adapters;

import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hms.NoticeModel;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;

public class NoticeAdapter extends RecyclerView.Adapter<NoticeAdapter.ViewHolder> {

    List<NoticeModel> items;
    private FragmentActivity mContext;

    public NoticeAdapter(FragmentActivity activity, ArrayList<String> date, ArrayList<String> data) {
        mContext = activity;
        items = new ArrayList<NoticeModel>();
        for (int i = 0; i < date.size(); i++) {
            NoticeModel item = new NoticeModel();
            item.setDate(date.get(i));
            item.setData(data.get(i));

            items.add(item);
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.notice_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        NoticeModel list = items.get(position);
        holder.date.setText(list.getDate());
        holder.data.setText(list.getData());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView date;
        public TextView data;

        public ViewHolder(View itemView) {
            super(itemView);

            date = itemView.findViewById(R.id.notice_date);
            data = itemView.findViewById(R.id.notice_data);

        }
    }
}
