package com.hms.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;
import com.hms.adapters.ComplainAdapter;
import com.hms.adapters.UserReportAdapter;

import java.util.ArrayList;


public class UserReportsFragment extends Fragment {
    View view;
    DatabaseReference users, userFetch;
    private ArrayList<String> user = new ArrayList<>();
    private ArrayList<String> plotno = new ArrayList<>();
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView userList1;
    private UserReportAdapter userReportAdapter;

    String usersName,usersPlot;

    public UserReportsFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("User Reports");

        view= inflater.inflate(R.layout.fragment_user_reports, container, false);

        userList1=view.findViewById(R.id.user_list);

        try {
            userFetch = FirebaseDatabase.getInstance().getReference().child("Plot");

            userFetch.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    usersName = String.valueOf(dataSnapshot.getKey());
                    usersPlot = (String)dataSnapshot.getValue();

                    plotno.add(usersPlot);
                    user.add(usersName);

                    userReportAdapter = new UserReportAdapter(getActivity(), user, plotno);

                    layoutManager = new LinearLayoutManager(getActivity());
                    userList1.setLayoutManager(layoutManager);

                    userList1.setAdapter(userReportAdapter);

                    /*names.add(value);
                    adapterUpdateMember.notifyDataSetChanged();*/
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }catch (Exception e){}

        return view;
    }
}
