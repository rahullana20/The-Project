/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAO;

import com.gniit.Clinico.Entity.Appointment;
import java.util.List;

/**
 *
 * @author Namrata
 */
public interface Appointment_Interface {
     int addappointment(Appointment appointment);
    int deleteAppointment(int Appointment_ID);
    List <Appointment> getAppointments();
    Appointment getAppointmentByID(int Appointment_ID);
    int updateAppointment(int Appointment_ID,Appointment appointment);
}
