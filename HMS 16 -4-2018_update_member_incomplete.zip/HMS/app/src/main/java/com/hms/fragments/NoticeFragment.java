package com.hms.fragments;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hms.adapters.NoticeAdapter;
import com.hms.R;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class NoticeFragment extends Fragment {

    private FirebaseDatabase database;
    private DatabaseReference reference;

    private RecyclerView recyclerView;
    private View rootView;
    ProgressDialog progress;
    private RecyclerView.LayoutManager layoutManager;
    private NoticeAdapter adapter;
    FloatingActionButton plus;
    private ArrayList<String> dateList = new ArrayList<>();
    private ArrayList<String> dataList = new ArrayList<>();
    String[] date = {"02-12-2017", "12-12-2017"};
    String[] data = {"abc","abc"};

    public NoticeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_notice, container, false);
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Notice");

        plus = rootView.findViewById(R.id.plus);

        if (plus!=null)
        {
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Fragment fragment = new NoticeAddAdminFragment();
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();
                }
            });
        }return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        recyclerView = rootView.findViewById(R.id.notice_list);
        layoutManager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(layoutManager);

        try {
            reference = database.getReference("Notice").child("3MpXje3ULfa8aBhyJbq0rGi0YMN2");
            //Calling AsyncTask to fetch data from server
            //new getNotice().execute();

            reference.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    for (DataSnapshot ds : dataSnapshot.getChildren()) {

                        String userMessage = ds.getValue(String.class);
                        //String userId = ds.getKey();
                        //dateList.add(userId);
                        dataList.add(userMessage);
                        //Log.d("ID", userId);
                        Log.d("MESSAGE", userMessage);

                        adapter.notifyDataSetChanged();
                    }
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });

            showData();
        }catch (Exception e){}
    }
    public void showData(){
        try {



            reference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                /*String value = String.valueOf(dataSnapshot.getChildren());
                Log.i("Value", "onChildAdded: "+value);
                dateList.add(value);*/
                    /*Toast.makeText(getActivity(), "qwertyui", Toast.LENGTH_SHORT).show();
                    for(DataSnapshot ds : dataSnapshot.getChildren()) {
                        new getNotice().onPreExecute();

                        String userMessage = ds.getValue(String.class);
                        String userId = ds.getKey();
                        dateList.add(userId);
                        dataList.add(userMessage);
                        Log.d("ID", userId);
                        Log.d("MESSAGE", userId);

                        adapter.notifyDataSetChanged();*/

                    String value = dataSnapshot.getValue(String.class);
                    dateList.add(value);
                    }


                @Override
                public void onCancelled(DatabaseError databaseError) {
                    Toast.makeText(getActivity(), "Error", Toast.LENGTH_SHORT).show();
                }
            });
            adapter = new NoticeAdapter(getActivity(), dateList, dataList);
            recyclerView.setAdapter(adapter);

        }catch (Exception e){}
    }

    //AsyncTask to get data from server
    public class getNotice extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            progress = new ProgressDialog(getActivity());
            progress.setMessage("Loading Notice...");
            progress.show();
            progress.setCancelable(false);
        }


        @Override
        protected String doInBackground(String... params) {

            /*try {

                if (!helper.isOnline()) {
                    result = "No Internet connectivity";
                    return result;
                }

                URL url = new URL(getResources().getString(R.string.server_url) + "quote-day-api.php");

                HttpURLConnection con = (HttpURLConnection) url.openConnection();
                //Post Method
                con.setRequestMethod("POST");
                con.setDoOutput(true);

                int read;
                String result = "";
                InputStream inputStream = con.getInputStream();
                while ((read = inputStream.read()) != -1) {
                    result += (char) read;
                }
                Log.i("result", "result is " + result);

                return result;

            } catch (Exception e) {
                e.printStackTrace();
            }*/
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            if (progress.isShowing())
                progress.dismiss();

            for (int i = 0; i < date.length; i++) {
                dateList.add(date[i]);
                dataList.add(data[i]);
            }

            adapter = new NoticeAdapter(getActivity(), dateList, dataList);
            recyclerView.setAdapter(adapter);

            /*if (progress.isShowing())
                progress.dismiss();
            if (result != null) {

                if (result.contains("No Internet connectivity")) {
                    final Snackbar snackbar = Snackbar
                            .make(getView(), "Please check your connection", Snackbar.LENGTH_INDEFINITE);
                    snackbar.setAction("RETRY", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            new getQuote().execute();
                            snackbar.dismiss();
                        }
                    });
                    snackbar.show();
                } else {


                    try {

                        JSONArray jsonarray = new JSONArray(result);
                        for (int i = 0; i < jsonarray.length(); i++) {
                            JSONObject jsonobject = jsonarray.getJSONObject(i);
                            date.add(jsonobject.getString("quote_date"));
                            Log.i("Date ", date + "");
                            quote.add(jsonobject.getString("quote_of_day"));
                            Log.i("quote ", quote + "");
                        }

                        quoteOfTheDayAdapter = new QuoteOfTheDayAdapter(getActivity(), date, quote);
                        recyclerView.setAdapter(quoteOfTheDayAdapter);

                    } catch (Exception e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            } else {
                Toast.makeText(getActivity(), "Could not fetch data! Please try again", Toast.LENGTH_SHORT).show();
            }*/
        }
    }
}
