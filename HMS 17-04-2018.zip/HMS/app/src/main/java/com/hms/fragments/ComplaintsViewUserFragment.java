package com.hms.fragments;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;
import com.hms.adapters.ComplainAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class ComplaintsViewUserFragment extends Fragment {

    FloatingActionButton plus;
    FragmentManager fragmentManager;
    View view;
    DatabaseReference ref;
    private ArrayList<String> title = new ArrayList<>();
    private ArrayList<String> message = new ArrayList<>();
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView complainList;
    private ComplainAdapter complainAdapter;

    public ComplaintsViewUserFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
            view = inflater.inflate(R.layout.fragment_complaints_view_user, container, false);

            complainList = view.findViewById(R.id.complain_list);
            plus = view.findViewById(R.id.plus);

            if (plus != null) {
                plus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Fragment fragment = new ComplaintsAddUserFragment();
                        fragmentManager = getFragmentManager();
                        fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();
                    }
                });
            }

         try {
            ref = FirebaseDatabase.getInstance().getReference("Complaints").child("o1SORcXwpXPZ1q0Vr7D1fysKu7U2");

            ref.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    String value = dataSnapshot.getValue(String.class);
                    message.add(value);

                    String key = dataSnapshot.getKey();
                    title.add(key);

                    complainAdapter =  new ComplainAdapter(getActivity(),title,message);

                    layoutManager = new LinearLayoutManager(getActivity());
                    complainList.setLayoutManager(layoutManager);

                    complainList.setAdapter(complainAdapter);
                    //noticeAdapter.notifyDataSetChanged();
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }catch (Exception e){}

            return view;
        }
    }

