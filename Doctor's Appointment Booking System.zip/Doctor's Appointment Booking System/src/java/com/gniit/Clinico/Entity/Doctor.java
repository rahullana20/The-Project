/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Entity;

/**
 *
 * @author Namrata
 */
public class Doctor {
    int Doctor_ID;
    String Name;
    String Specialist;
    String Email_ID;
    int Contact_No;
    

  

    public int getDoctor_ID() {
        return Doctor_ID;
    }

    public void setDoctor_ID(int Doctor_ID) {
        this.Doctor_ID = Doctor_ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEmail_ID() {
        return Email_ID;
    }

    public void setEmail_ID(String Email_ID) {
        this.Email_ID = Email_ID;
    }

    public int getContact_No() {
        return Contact_No;
    }

    public void setContact_No(int Contact_No) {
        this.Contact_No = Contact_No;
    }

    public String getSpecialist() {
        return Specialist;
    }

    public void setSpecialist(String Specialist) {
        this.Specialist = Specialist;
    }
    public Doctor(){}

    public Doctor(int id, String name,String specialist, String emailid, int contactno) {
        this.Doctor_ID = id;
        this.Name = name;
         this.Specialist = specialist;
        this.Email_ID = emailid;
    this.Contact_No = contactno;
   
    }

    public Doctor(String name,String specialist, String emailid, int contactno) {
        this.Name = name;
      this.Specialist = specialist;
        this.Email_ID = emailid;
        this.Contact_No = contactno;
      
    }
}