package com.hms.fragments;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;

import com.hms.R;



public class DeleteMemberFragment extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {
    View view;
    Spinner deleteSpinner;
    Button delete;

    public DeleteMemberFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_delete_member, container, false);

        deleteSpinner=(Spinner) view.findViewById(R.id.deletespinner);
        delete=(Button) view.findViewById(R.id.deletebutton);

        delete.setOnClickListener(this);

        return view;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
