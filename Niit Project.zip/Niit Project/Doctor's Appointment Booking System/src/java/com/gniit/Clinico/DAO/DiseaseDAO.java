/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAO;

import com.gniit.Clinico.Entity.Disease;
import java.util.List;

/**
 *
 * @author Namrata
 */
public interface DiseaseDAO {
    int adddisease(Disease disease);
    int deleteDisease(int Disease_ID);
    List <Disease> getDiseases();
    Disease getDiseaseByID(int Disease_ID);
    int updateDisease(int Disease_ID,Disease disease);
}
