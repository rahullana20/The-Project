package com.hms;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Activity extends AppCompatActivity {

    EditText a,b;
    Button button;
    FirebaseDatabase database;
    DatabaseReference myRef;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);


        b = (EditText) findViewById(R.id.userPassword);
        button = (Button)findViewById(R.id.Submit123);
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference("User/qwerty");

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                 // when data is changed
                String s = dataSnapshot.getValue(String.class);
                TextView changedValue = (TextView)findViewById(R.id.textView4);
                changedValue.setText(s);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                //when it fails to fetch any data

            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                a = (EditText) findViewById(R.id.nameUser);
                String msg = a.getText().toString();
                myRef.child("qwerty").push().setValue(msg);
            }
        });

    }
}
