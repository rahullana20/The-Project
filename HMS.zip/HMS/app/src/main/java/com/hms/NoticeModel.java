package com.hms;

/**
 * Created by Dashesh on 13-01-2018.
 */

public class NoticeModel {
    private String date;
    private String data;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getData() {
        return data;
    }

    public void setData(String quote) {
        this.data = quote;
    }
}
