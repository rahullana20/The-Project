package com.gniit.Clinico.DAOimpl;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import DB_Connection.DBconnection;
import com.gniit.Clinico.Entity.Patient;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.gniit.Clinico.DAO.PatientDAO;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

/**
 *
 * @author Namrata
 */
public class PatientDAOImpl implements PatientDAO {

    @Override
    public int addpatient(Patient patient) {
        int count=0;
       
        try{ Connection con=DBconnection.getConnection();
              PreparedStatement preparedStatement = con.prepareStatement("insert into Patient(PatientId,Name,pAddress,pEmailId,pContactNo,pDOB) values(?,?,?,?,?,?)");
            preparedStatement.setInt(1,patient.getPatient_ID());
            preparedStatement.setString(2,patient.getName());
            preparedStatement.setString(3,patient.getAddress());
            preparedStatement.setString(4,patient.getEmail_ID());
            preparedStatement.setInt(5,patient.getContact_No());
            java.util.Date joindate = new java.util.Date(patient.getjoindate());
            preparedStatement.setDate(6, (java.sql.Date) new Date(joindate.getYear(),joindate.getMonth(),joindate.getDate()));
            count = preparedStatement.executeUpdate();
            
        } catch (SQLException ex) { 
         Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
     } 
           
       
      return count;
    }

    @Override
    public int deletePatient(int Patient_ID) {
        int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Patient where PatientID=?");
            preparedStatement.setInt(1,Patient_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
        
        
    }

    @Override
    public List<Patient> getPatients() {
        List<Patient> patientList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Patient");
            ResultSet rs = preparedStatement.executeQuery();
            patientList = new ArrayList<Patient>();
            if(rs!=null){
               
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String address = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                    String joindate = rs.getString(6);
                    String pass=rs.getString(7);
                    Patient patient = new Patient(id,name,address,emailid,contactno,joindate,pass);
                    patientList.add(patient);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return patientList;

        
    }

    @Override
    public Patient getPatientByID(int Patient_ID) {
         List<Patient> patientList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Patient where PatientId=?");
            preparedStatement.setInt(1, Patient_ID);
            ResultSet rs = preparedStatement.executeQuery();
           patientList = new ArrayList<Patient>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String address = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                    String joindate = rs.getString(6);
                    String pass=rs.getString(7);
                    Patient patient = new Patient(id,name,address,emailid,contactno,joindate,pass);
                    patientList.add(patient);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(patientList.size()>0) return patientList.get(0);
     else return null;
        
    }

    @Override
    public int updatePatient(int Patient_ID, Patient patient) {
         int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Patient set Name=?, pAddress=?, pEmailId=?, pContactNo=?, pDOB=? where PatientID=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,patient.getPatient_ID());
            pst.setString(2,patient.getName());
            pst.setString(3,patient.getAddress());
              pst.setString(4,patient.getEmail_ID());
                pst.setInt(5,patient.getContact_No());
                  pst.setString(6,patient.getjoindate());
                  count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
    @Override
 public boolean isValidate(String Email_ID)
 {
      boolean result = true;
   try {
      InternetAddress emailAddr = new InternetAddress(Email_ID);
      emailAddr.validate();
   } catch (AddressException ex) {
      result = false;
   }
   return result;
}
 
 
    @Override
  public boolean validUser(int Patient_ID, String password)
 {
 try {
          Connection con = DBconnection.getConnection();
          PreparedStatement pst = con.prepareStatement("select PatientId, password from Patient where PatientId = ? and password = ?");

          pst.setInt(1,Patient_ID);
          pst.setString(2, password);

          ResultSet rs = pst.executeQuery();
          String rsUserName = null;
          String rsPassword = null;
          if(rs.next()){
              rsUserName = rs.getString("Patient_ID");
              rsPassword =  rs.getString("password");    
          }

          con.close();

          if (rsUserName.equals(Patient_ID) && rsPassword.equals(password)){
              return true;
          }



        } catch (SQLException ex) {
            Logger.getLogger(PatientDAOImpl.class.getName()).log(Level.SEVERE, null, ex);

        }
        return false; 
      }
}
    

