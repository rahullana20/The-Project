package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.hms.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragment extends Fragment implements View.OnClickListener,AdapterView.OnItemSelectedListener {
    View view;
    Spinner monthSpinner;
    Spinner yearSpinner;
    Button submitadmin;
    Button downloadPdf;
    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    public MaintenanceFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view=inflater.inflate(R.layout.fragment_maintenance, container, false);
       monthSpinner=(Spinner)view.findViewById(R.id.monthspinneradmin);
       yearSpinner = (Spinner)view.findViewById(R.id.yearspinneradmin);
       submitadmin=(Button)view.findViewById(R.id.submitadmin);
        downloadPdf=(Button)view.findViewById(R.id.downloadpdf);
        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);

        monthSpinner.setAdapter(adapterMonths);
        yearSpinner.setAdapter(adapterYears);

        monthSpinner.setOnItemSelectedListener(this);
        yearSpinner.setOnItemSelectedListener(this);
        submitadmin.setOnClickListener(this);
        downloadPdf.setOnClickListener(this);
       return view;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    public void onClick(View v) {

    }
}
