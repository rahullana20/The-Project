package com.hms.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.hms.JavaClasses.CommonMethods;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;
import android.widget.AdapterView.OnItemSelectedListener;

import static android.view.View.*;
import static android.widget.Toast.makeText;

public class RegisterActivity extends AppCompatActivity implements OnClickListener, OnItemSelectedListener {
    AutoCompleteTextView name;
    AutoCompleteTextView email;
    EditText password;
    String plot_no;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button sign_up;
    Spinner plot_spinner;
    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;
    String [] plots=new String[]{"A101","A102","A103","B101","B102","B103","C101","C102","C103"};

    TextView loginLink;
    final String value = "deepak.jain186@gmail.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        if (CommonMethods.isOnline(getBaseContext())) {
            try {
                if (mAuth.getCurrentUser().getEmail().equals(value)) {
                    startActivity(new Intent(this, AdminActivity.class));
                } else if (mAuth.getCurrentUser() != null) {
                    //start the main profile
                    finish();
                    startActivity(new Intent(this, UserActivity.class));
                }
            }catch (Exception e){}
        }
        else {
            makeText(this, "Please check internet connection", Toast.LENGTH_SHORT).show();
        }

        progressDialog = new ProgressDialog(this);

        loginLink = findViewById(R.id.labeltextview);
        name = findViewById(R.id.fullname);
        email = findViewById(R.id.emailRegister);
        password = findViewById(R.id.password);
        //plot_no = findViewById(R.id.plotspinner);
        number_of_members = findViewById(R.id.totalmembers);
        contact_no = findViewById(R.id.contactno);
        swimming_pool = findViewById(R.id.swimmingpoolcb);
        sports_club = findViewById(R.id.sportsclubcb);
        aadhar_card_no = findViewById(R.id.aadharno);
        sign_up = findViewById(R.id.sign_up_register);

        loginLink.setOnClickListener(this);
        sign_up.setOnClickListener(this);


        plot_spinner= (Spinner) findViewById(R.id.plotspinner);
        ArrayAdapter adapterPlots = new ArrayAdapter(this,android.R.layout.simple_list_item_1,plots);
        plot_spinner.setAdapter(adapterPlots);
        plot_spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View view) {

        if (view == sign_up) {
            //fetching data
            final String Name = name.getText().toString().trim();
            final String emailId = email.getText().toString().trim();
            final String pass = password.getText().toString().trim();



            //final String plot = plot_no.toString().trim();
            final String countMembers = number_of_members.getText().toString().trim();
            final String contact = contact_no.getText().toString();
            final String aadhar = aadhar_card_no.getText().toString().trim();
          //  System.out.println("plot no="+ plot_no);
            final String checkSwim, checkSports;
            if (swimming_pool.isChecked()) {
                checkSwim = "Yes";
            } else {
                checkSwim = "No";
            }
            if (sports_club.isChecked()) {
                checkSports = "Yes";
            } else {
                checkSports = "No";
            }

            if (TextUtils.isEmpty(Name)) {
                makeText(this, "Name cannot be blank", Toast.LENGTH_LONG).show();
                name.setError("Enter name");
                return;
            } else if (TextUtils.isEmpty(plot_no)) {
                makeText(this, "Plot Number cannot be blank", Toast.LENGTH_LONG).show();
                //plot_no.setError("Enter plot number");
                return;
            } else if (TextUtils.isEmpty(emailId)) {
                makeText(this, "Email ID cannot be blank", Toast.LENGTH_LONG).show();
                email.setError("Enter email address");
                return;
            } else if (TextUtils.isEmpty(pass)) {
                makeText(this, "Password cannot be blank", Toast.LENGTH_LONG).show();
                password.setError("Enter password");
                return;
            } else if (TextUtils.isEmpty(countMembers)) {
                makeText(this, "Number of members cannot be blank", Toast.LENGTH_LONG).show();
                number_of_members.setError("Enter number of members staying");
                return;
            } else if (TextUtils.isEmpty(contact)) {
                makeText(this, "Contact Number cannot be blank", Toast.LENGTH_LONG).show();
                contact_no.setError("Enter contact number");
                return;
            } else if (TextUtils.isEmpty(aadhar)) {
                makeText(this, "Aadhar cannot be blank", Toast.LENGTH_LONG).show();
                aadhar_card_no.setError("Enter aadhar number");
                return;
            }
            progressDialog.setMessage("Registering User");
            progressDialog.show();

            if (CommonMethods.isOnline(getBaseContext())) {
                mAuth.createUserWithEmailAndPassword(emailId, pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful() == true) {
                            progressDialog.dismiss();
                            DatabaseQueries dq = new DatabaseQueries();
                            dq.updateRegister(Name, emailId, pass, plot_no,countMembers, contact, aadhar,checkSwim,checkSports);
                            finish();
                            startActivity(new Intent(RegisterActivity.this, UserActivity.class));
                        }
                        else if (task.isSuccessful() == false)
                        {
                            progressDialog.dismiss();
                            makeText(RegisterActivity.this, "PLease enter valid data.", Toast.LENGTH_SHORT).show();
                            name.getText().clear();
                            email.getText().clear();
                            password.getText().clear();
                            number_of_members.getText().clear();
                            contact_no.getText().clear();
                            aadhar_card_no.getText().clear();
                            name.requestFocus();
                            return;
                        }
                    }
                });
            } else {
                progressDialog.dismiss();
                makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
            }
        }
        else if (view == loginLink) {
            finish();
            startActivity(new Intent(RegisterActivity.this, Login.class));
        }
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        plot_no = parent.getItemAtPosition(position).toString();

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}