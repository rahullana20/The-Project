package com.hms.Model;

/**
 * Created by Dashesh on 13-01-2018.
 */

public class MenuModel {

    public int icon;
    public String name;

    // Constructor.
    public MenuModel(int icon, String name) {

        this.icon = icon;
        this.name = name;
    }

}
