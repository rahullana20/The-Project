package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;


/**
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragment extends Fragment{
    View view;
    Spinner monthSpinner;
    Spinner yearSpinner;
    Spinner nameSpinner;
    Spinner statusSpinner;
    Button submitadmin;

    List<String> names = new ArrayList<>();

    String month, year, name, status, valueFirebase;

    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    String [] bill_status= new String[]{"Not Paid","Paid"};
    public MaintenanceFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view=inflater.inflate(R.layout.fragment_maintenance, container, false);

       monthSpinner=(Spinner)view.findViewById(R.id.monthspinneradmin);
       yearSpinner = (Spinner)view.findViewById(R.id.yearspinneradmin);
       nameSpinner =(Spinner)view.findViewById(R.id.namespinneradmin);
       statusSpinner =(Spinner) view.findViewById(R.id.statuspinneradmin);

       submitadmin= view.findViewById(R.id.submitadmin);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);
        final ArrayAdapter adapterName = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,names);
        ArrayAdapter adapterStatus = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,bill_status);

        adapterName.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        monthSpinner.setAdapter(adapterMonths);
        yearSpinner.setAdapter(adapterYears);
        nameSpinner.setAdapter(adapterName);
        statusSpinner.setAdapter(adapterStatus);

        //adding data to spinner
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                valueFirebase = String.valueOf(dataSnapshot.getKey());

                names.add(valueFirebase);
                adapterName.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        monthSpinner.setAdapter(adapterMonths);
        yearSpinner.setAdapter(adapterYears);
        nameSpinner.setAdapter(adapterName);
        statusSpinner.setAdapter(adapterStatus);

        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                year = yearSpinner.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        monthSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                month = monthSpinner.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        nameSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                name = nameSpinner.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        statusSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                status = statusSpinner.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        submitadmin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Boolean bool = DatabaseQueries.addMaintenanceStatus(year, month, name, status);
                if (bool == true){
                    Toast.makeText(getActivity(), "Maintenance Status was not added", Toast.LENGTH_SHORT).show();
                }else {
                    Toast.makeText(getActivity(), "Maintenance Status was added", Toast.LENGTH_SHORT).show();
                }
            }
        });

       return view;
    }

}
