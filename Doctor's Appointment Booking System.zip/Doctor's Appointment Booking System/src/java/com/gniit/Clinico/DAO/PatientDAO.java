/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAO;

import com.gniit.Clinico.Entity.Patient;
import java.util.List;

/**
 *
 * @author Namrata
 */
public interface PatientDAO {

  
    int addPatient(Patient patient);
    int deletePatient(int Patient_ID);
    List <Patient> getPatients();
    Patient getPatientByID(int Patient_ID);
    int updatePatient(int Patient_ID,Patient patient);
    boolean isValidate(String Email_ID);
    boolean validUser(String Username, String password);
}
