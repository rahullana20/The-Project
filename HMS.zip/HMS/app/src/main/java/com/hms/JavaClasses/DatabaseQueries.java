package com.hms.JavaClasses;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.activities.Login;
import com.hms.activities.UserActivity;
import com.hms.adapters.ComplainAdapter;
import com.hms.fragments.ComplaintsViewUserFragment;

import java.util.ArrayList;

import static android.support.v4.content.ContextCompat.startActivity;

/**
 * Created by Deepak jain on 23-03-2018.
 */

public class DatabaseQueries {

    String value, checkEmailVal, checkEmailKey;

    public static void updateRegister(String name, String emailID, String pass, String plot, String countmembers, String contact,
                                      String aadhar, String checkSwim, String checkSports){

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference query = database.getReference().child("Accounts");

        query.child(name);
        query.child(name).child("EmailId").setValue(emailID);
        query.child(name).child("Password").setValue(pass);
        query.child(name).child("PlotNumber").setValue(plot);
        query.child(name).child("TotalNumberOfMembers").setValue(countmembers);
        query.child(name).child("ContactNumber").setValue(contact);
        query.child(name).child("Aadhar").setValue(aadhar);
        query.child(name).child("SwimmingPool").setValue(checkSwim);
        query.child(name).child("SportsClub").setValue(checkSports);
        query.child(name).child("Maintenance").child("");
        query.child(name).child("Tenants").child("");
        query.child(name).child("Parking").child("");
    }

    public static boolean addComplaint(String titleC, String messageC){
        FirebaseAuth mAuth;
        mAuth = FirebaseAuth.getInstance();

        String uid = mAuth.getCurrentUser().getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference query = database.getReference("Complaints");

        boolean flag = query.child(uid).child(titleC).setValue(messageC).isSuccessful();
        return flag;
    }

    public static boolean addNotice(String titleC, String messageC){
        FirebaseAuth mAuth;
        mAuth = FirebaseAuth.getInstance();

        String uid = mAuth.getCurrentUser().getUid();

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference query = database.getReference("Notice");

        boolean flag = query.child(uid).child(titleC).setValue(messageC).isSuccessful();
        return flag;
    }

    public static boolean updateMember(String val,String count, String contact, String aadhar, String swim,String sports){
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference query = database.getReference("Accounts");

        query.child(val);
        boolean flag = query.child(val).child("TotalNumberOfMembers").setValue(count).isSuccessful();
        query.child(val).child("ContactNumber").setValue(contact);
        query.child(val).child("Aadhar").setValue(aadhar);
        query.child(val).child("SwimmingPool").setValue(swim);
        query.child(val).child("SportsClub").setValue(sports);

        return flag;
    }

    public static void enterPlot(String name,String plot){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Plot");

        ref.child(name).setValue(plot);
    }

    public static boolean addMaintenanceStatus(String year, String month, String name, String status){
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");
        boolean bool = ref.child(name).child("Maintenance").child(year).child(month).setValue(status).isSuccessful();
        return bool;
    }

    /*public void deleteMember(final String email){
        DatabaseReference delete = FirebaseDatabase.getInstance().getReference().child("Accounts");

        //to get children(accounts)
        delete.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                value = dataSnapshot.getValue(String.class);

                getChild(value, email);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });


        *//*if (deletekey.equals("EmailID")){
            FirebaseAuth mAuth = FirebaseAuth.getInstance();

        }*//*
    }

    public void getChild(String value, String email){
        DatabaseReference checkEmail = FirebaseDatabase.getInstance().getReference().child("Accounts").child(value);

        checkEmail.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                checkEmailVal = dataSnapshot.getValue(String.class);
                checkEmailKey = dataSnapshot.getKey();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        if (checkEmailKey.equals("EmailId")){
            if (checkEmailVal.equals(email)){
                checkEmail.child(checkEmailKey).getParent().setValue(null);
            }
        }
    }*/
}
