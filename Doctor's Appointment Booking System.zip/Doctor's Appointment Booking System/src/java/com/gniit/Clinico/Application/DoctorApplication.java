/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Application;

import com.gniit.Clinico.DAOimpl.Doctor_Impl;
import com.gniit.Clinico.DoctorDAO.Doctor_Interface;
import com.gniit.Clinico.Entity.Doctor;
import java.util.List;

/**
 *
 * @author Namrata
 */
public class DoctorApplication {
    public static void main(String[] args){
        Doctor_Interface doctorDAO = new Doctor_Impl();
              int count = doctorDAO.adddoctor(new Doctor(3,"Saloni","bdthn","sty",49816));
        if(count>0)System.out.println("Record Added Successfully");
        else System.out.println("Record Failed to get added");
 //count=doctorDAO.deleteDoctor(1);
   //   if(count>0)System.out.println("Record Deleted Successfully");
     //  else System.out.println("Record Failed to get deleted");
      //  Doctor doc = new Doctor(2,"Nick","fvdv","ert",5425);
     //count=doctorDAO.updateDoctor(2, doc);
       // if(count>0)System.out.println("Record Updated Successfully");
        //else System.out.println("Record Failed to get updated");
     //    List<Doctor> doctorlist = doctorDAO.getDoctors();
       // for(Doctor emp : doctorlist){
         //   System.out.println(emp.getDoctor_ID() + "|" + emp.getName() + "|" + emp.getSpecialist() + "|" + emp.getEmail_ID() + "|" + emp.getContact_No());
      //}
    Doctor doct= doctorDAO.getDoctorByID(2);
            System.out.println(doct.getContact_No()+ "|" + doct.getEmail_ID() + "|" + doct.getName() + "|" + doct.getSpecialist());

}
}
