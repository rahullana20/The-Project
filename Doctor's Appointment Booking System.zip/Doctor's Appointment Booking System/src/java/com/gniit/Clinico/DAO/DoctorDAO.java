/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DoctorDAO;

import com.gniit.Clinico.Entity.Doctor;
import java.util.List;

/**
 *
 * @author Namrata
 */
public interface DoctorDAO {
    int addDoctor(Doctor doctor);
    int deleteDoctor(int Doctor_ID);
    List <Doctor> getDoctors();
    Doctor getDoctorByID(int Doctor_ID);
    int updateDoctor(int Doctor_ID,Doctor doctor);
    boolean isValidate(String Email_ID);
    boolean validUser(int Doctor_ID, String dpassword);
}
