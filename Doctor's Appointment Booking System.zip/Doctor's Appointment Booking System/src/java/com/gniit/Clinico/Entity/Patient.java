/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.Entity;

import java.util.Date;

/**
 *
 * @author Namrata
 */
public class Patient {
    int Patient_ID;
    String Name;
    String Address;
    String Email_ID;
    int Contact_No;
    String joindate;

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    String password;

    public void setjoindate(String joindate) {
      this.joindate=joindate;
    }

    public int getPatient_ID() {
        return Patient_ID;
    }

    public void setPatient_ID(int Patient_ID) {
        this.Patient_ID = Patient_ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getEmail_ID() {
        return Email_ID;
    }

    public void setEmail_ID(String Email_ID) {
        this.Email_ID = Email_ID;
    }

    public int getContact_No() {
        return Contact_No;
    }

    public void setContact_No(int Contact_No) {
        this.Contact_No = Contact_No;
    }

    public String getjoindate() {
        return joindate;
    }

    

 public Patient(){}

    public Patient(int id, String name, String address, String emailid, int contactno, String Joindate, String pass) {
        this.Patient_ID = id;
        this.Name = name;
        this.Address = address;
        this.Email_ID = emailid;
    this.Contact_No = contactno;
    this.joindate = Joindate;
    this.password=pass;
    }

    public Patient(String name, String address, String emailid, int contactno, String Joindate, String pass) {
        this.Name = name;
        this.Address = address;
        this.Email_ID = emailid;
        this.Contact_No = contactno;
        this.joindate = Joindate;
    this.password=pass;
    }
}
