/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAOimpl;

import DB_Connection.DBconnection;
import com.gniit.Clinico.Entity.Disease;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.gniit.Clinico.DAO.DiseaseDAO;

/**
 *
 * @author Namrata
 */
public class DiseaseDAOImpl implements DiseaseDAO {
 Connection con=DBconnection.getConnection();
    @Override
    public int adddisease(Disease disease) {
         int count=0;
       
        try {
             String query="insert into Disease(DiseaseId,DiseaseName,Symptoms,Remedies,DoctorId) values(?,?,?,?,?)";
             
      PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,disease.getDisease_ID());
            pst.setString(2,disease.getDisease_Name());
            pst.setString(3,disease.getDisease_Symptoms());
              pst.setString(4,disease.getDisease_Remedies());
                pst.setInt(5,disease.getDoctor_ID());
                 
            count = pst.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(DiseaseDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
      return count;
   
    }

    @Override
    public int deleteDisease(int Disease_ID) {
         int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Disease where DiseaseId=?");
            preparedStatement.setInt(1,Disease_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DiseaseDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
       
    }

    @Override
    public List<Disease> getDiseases() {
         List<Disease> diseaseList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Disease");
            ResultSet rs = preparedStatement.executeQuery();
            diseaseList = new ArrayList<Disease>();
            if(rs!=null){
               
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String sym = rs.getString(3);
                    String rem = rs.getString(4);
                    int did = rs.getInt(5);
                    
                    Disease disease = new Disease(id,name,sym,rem,did);
                    diseaseList.add(disease);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DiseaseDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return diseaseList;

    }

    @Override
    public Disease getDiseaseByID(int Disease_ID) {
         List<Disease> diseaseList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Disease where DiseaseId=?");
            preparedStatement.setInt(1, Disease_ID);
            ResultSet rs = preparedStatement.executeQuery();
           diseaseList = new ArrayList<Disease>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String sym = rs.getString(3);
                    String rem = rs.getString(4);
                    int did = rs.getInt(5);
                   
                    Disease disease = new Disease(id,name,sym,rem,did);
                    diseaseList.add(disease);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DiseaseDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(diseaseList.size()>0) return diseaseList.get(0);
     else return null;
       
    }

    @Override
    public int updateDisease(int Disease_ID, Disease disease) {
        int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Disease set DiseaseName=?, Symptoms=?, Remedies=?, DoctorId=? where DiseaseId=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,disease.getDisease_ID());
            pst.setString(2,disease.getDisease_Name());
            pst.setString(3,disease.getDisease_Symptoms());
              pst.setString(4,disease.getDisease_Remedies());
                pst.setInt(5,disease.getDoctor_ID());
              
                  count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DiseaseDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
    
}
