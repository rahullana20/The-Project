package com.hms.JavaClasses;

/**
 * Created by Rahul on 24-09-2017.
 */

public class Constants {

    public static final String STRING = "STRING";
    public static final String INT = "INT";
    public static final String FLOAT = "FLOAT";
    public static final String LONG = "LONG";
    public static final String BOOLEAN = "BOOLEAN";
}
