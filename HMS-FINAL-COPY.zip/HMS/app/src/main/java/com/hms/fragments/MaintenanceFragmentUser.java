package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;

import org.w3c.dom.Attr;
import org.w3c.dom.CDATASection;
import org.w3c.dom.Comment;
import org.w3c.dom.DOMConfiguration;
import org.w3c.dom.DOMException;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.DocumentFragment;
import org.w3c.dom.DocumentType;
import org.w3c.dom.Element;
import org.w3c.dom.EntityReference;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.ProcessingInstruction;
import org.w3c.dom.Text;
import org.w3c.dom.UserDataHandler;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * .
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragmentUser extends Fragment {
    private View view;

    TextView jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec;
    String yearSpinnerfirst, yearSpinnerSecond, monthSpinnerSecond, accountsFirebase, getEmail;
    String emailFromFirebase, getEmailValue;
    String month, monthValue, accountVerified;
    String arrayMonth[], arrayMonthValue[];
    int i = 0;
    Boolean checkedEmail = false;
    Boolean checkedValueAnswer = false;
    private DatabaseReference maintenancefetch = FirebaseDatabase.getInstance().getReference().child("Accounts");
    Spinner yearSpinner;
    private Spinner monthSpinnerPdf;
    private Spinner yearSpinnerPdf;
    private Button downloadPdf;
    private String[] months = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
    private String[] years = new String[]{"2018","2017","2016","2015"};
    ArrayList<String> arraymonth = new ArrayList<>();
    ArrayList<String> arraymonthvalue = new ArrayList<>();

    public MaintenanceFragmentUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        // return inflater.inflate(R.layout.MaintenanceFragmentUser, container, false);
        view = inflater.inflate(R.layout.fragment_maintenance_user, container, false);

        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");

        jan = view.findViewById(R.id.janStatus);
        feb = view.findViewById(R.id.febStatus);
        mar = view.findViewById(R.id.marStatus);
        apr = view.findViewById(R.id.aprStatus);
        may = view.findViewById(R.id.mayStatus);
        jun = view.findViewById(R.id.junStatus);
        jul = view.findViewById(R.id.julStatus);
        aug = view.findViewById(R.id.augStatus);
        sep = view.findViewById(R.id.sepStatus);
        oct = view.findViewById(R.id.octStatus);
        nov = view.findViewById(R.id.novStatus);
        dec = view.findViewById(R.id.decStatus);

        yearSpinner = view.findViewById(R.id.yearspinneruser);
        monthSpinnerPdf = view.findViewById(R.id.monthspinnerpdf);
        yearSpinnerPdf = view.findViewById(R.id.yearspinnerpdf);

        downloadPdf = view.findViewById(R.id.downloadpdf);

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(), android.R.layout.simple_list_item_1, years);

        yearSpinner.setAdapter(adapterYears);
        monthSpinnerPdf.setAdapter(adapterMonths);
        yearSpinnerPdf.setAdapter(adapterYears);

        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerfirst = yearSpinner.getItemAtPosition(i).toString();
                Toast.makeText(getActivity(), yearSpinnerfirst, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        monthSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                monthSpinnerSecond = monthSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        yearSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerSecond = yearSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        downloadPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putString("Year", yearSpinnerSecond);
                bundle.putString("Month", monthSpinnerSecond);
                bundle.putString("Name", accountVerified);

                FragmentManager fragmentManager = getActivity().getSupportFragmentManager();
                FragmentTransaction transaction = fragmentManager.beginTransaction();

                Bill bill = new Bill();
                bill.setArguments(bundle);

                transaction.replace(R.id.activity_main, bill);
                transaction.commit();
            }
        });

        //name of the accounts
        ref.addChildEventListener(new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    accountsFirebase = dataSnapshot.getKey(); //Deepak Jain
                    System.out.println("Account" + "  " + accountsFirebase);
                    checkedValueAnswer = getEmailKey(accountsFirebase);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        return view;
    }

    //get email as a key
    public boolean getEmailKey(String accounts) {//Deepak Jain
        try {
            DatabaseReference refEmail = FirebaseDatabase.getInstance().getReference().child("Accounts").child(accounts);//Deepak Jain

            final String accountsValue = accounts;//Deepak Jain

            refEmail.addChildEventListener(new ChildEventListener() {
                @Override
                public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                    try {
                        //True if the authentication and database(email) matches
                        if (checkedEmail == true) {
                            Toast.makeText(getActivity(), "Email Verified", Toast.LENGTH_SHORT).show();
                            return;
                        } else if (checkedEmail == false) {
                            getEmail = String.valueOf(dataSnapshot.getKey());//EmailId
                            getEmailValue = String.valueOf(dataSnapshot.getValue());//deepak.jain186@gmail.com

                            System.out.println(getEmail + " " + getEmailValue);
                            //true
                            if (getEmail.equals("EmailId")) {

                                System.out.println("check " + " " + getEmail + "  " + getEmailValue + " = " + accountsValue);

                                checkedEmail = checkEmail(accountsValue, getEmailValue);
                            }
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }

                @Override
                public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onChildRemoved(DataSnapshot dataSnapshot) {

                }

                @Override
                public void onChildMoved(DataSnapshot dataSnapshot, String s) {

                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {

        }
        return checkedEmail;
    }

    public boolean checkEmail(String accounts, String emailValue) {

        try {
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            emailFromFirebase = mAuth.getCurrentUser().getEmail();

            System.out.println("Current Directory " + accounts);

            if (emailFromFirebase.equals(emailValue)) {
                //Data Fetch
                accountVerified = accounts;
                System.out.println("Emails Match: " + emailFromFirebase + " & " + emailValue);
                mainFetchData(accounts);
            } else
                System.out.println("Emails Does not Match: " + emailFromFirebase + " & " + emailValue);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public void mainFetchData(String account) {
        Log.i("Account", account + yearSpinnerfirst);

        System.out.println(" qwertyuiop" + account);
        maintenancefetch = maintenancefetch.child(account).child("Maintenance").child(yearSpinnerfirst);
        maintenancefetch.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    month = dataSnapshot.getKey();
                    monthValue = dataSnapshot.getValue().toString();

                    System.out.println(month + "'s Maintenance: " + monthValue);

                /*  arrayMonth[i] = month;
                    arrayMonthValue[i] = monthValue;
                    i++;
                */

                    if (month.equals("Jan")) {
                        jan.setText(monthValue);
                    }
                    if (month.equals("Feb")) {
                        feb.setText(monthValue);
                    }
                    if (month.equals("Mar")) {
                        mar.setText(monthValue);
                    }
                    if (month.equals("Apr")) {
                        apr.setText(monthValue);
                    }
                    if (month.equals("May")) {
                        may.setText(monthValue);
                    }
                    if (month.equals("Jun")) {
                        jun.setText(monthValue);
                    }
                    if (month.equals("Jul")) {
                        jul.setText(monthValue);
                    }
                    if (month.equals("Aug")) {
                        aug.setText(monthValue);
                    }
                    if (month.equals("Sep")) {
                        sep.setText(monthValue);
                    }
                    if (month.equals("Oct")) {
                        oct.setText(monthValue);
                    }
                    if (month.equals("Nov")) {
                        nov.setText(monthValue);
                    }
                    if (month.equals("Dec")) {
                        dec.setText(monthValue);
                    }
                    /*arraymonth.add(month);
                    arraymonthvalue.add(monthValue);*/
                    //updateValue(month, monthValue);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {


            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    /*public void updateValue(String arrayMonth, String arrayMonthValue){
        ArrayList<String> arraymonth= new ArrayList<>();
        arraymonth.add(arrayMonth);
        System.out.println("Month: "+arraymonth);


        ArrayList<String> arraymonthvalue= new ArrayList<>();
        arraymonthvalue.add(arrayMonthValue);
        System.out.println("Month's Maintenance: "+arraymonthvalue);
    }*/
}
