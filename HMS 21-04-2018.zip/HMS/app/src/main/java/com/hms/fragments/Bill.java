package com.hms.fragments;


import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class Bill extends Fragment {
    TextView billno, flatno, name, swimmingpooltv, clubtv, month, year, totaltv;
    View view;
    String keyValue, value, plot, swimPool, clubMember, swimPrice, clubPrice;
    String nameFragment;

    public Bill() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_bill, container, false);

        Bundle bundle = getArguments();
        String yearFragment = bundle.getString("Year");
        String monthFragment = bundle.getString("Month");
        nameFragment = bundle.getString("Name");

        billno = view.findViewById(R.id.billno);
        flatno = view.findViewById(R.id.flatno);
        name = view.findViewById(R.id.name);
        swimmingpooltv = view.findViewById(R.id.swimmingpooltv);
        clubtv = view.findViewById(R.id.clubtv);
        month = view.findViewById(R.id.monthValuee);
        year = view.findViewById(R.id.yearrr);
        totaltv = view.findViewById(R.id.totaltv);
        try {
            checkValueAmount();
        }catch (Exception e){
            e.printStackTrace();
        }
        year.setText(yearFragment);
        month.setText(monthFragment);
        billno.setText("1");
        name.setText(nameFragment);


        return view;
    }

    public void checkValueAmount() {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");
        ref = ref.child(nameFragment);
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                value = dataSnapshot.getKey();
                keyValue = String.valueOf(dataSnapshot.getValue());

                if (value.equals("PlotNumber")) {
                    plot = keyValue;
                    System.out.println(value + ": " + plot);
                    flatno.setText(plot);
                }
                if (value.equals("SwimmingPool")) {
                    swimPool = keyValue;

                    if (swimPool.equals("Yes")) {
                        swimPrice = "500";
                    } else if (swimPool.equals("No")) {
                        swimPrice = "0";
                    }
                    swimmingpooltv.setText(swimPrice);

                    System.out.println(value + ": " + swimPool + " Value: " + swimPrice);
                }
                if (value.equals("SportsClub")) {
                    clubMember = keyValue;

                    if (clubMember.equals("Yes")) {
                        clubPrice = "1000";
                    } else if (clubMember.equals("No")) {
                        clubPrice = "0";
                    }
                    clubtv.setText(clubPrice);

                    System.out.println(value + ": " + clubMember + " Value: " + clubPrice);
                }
                getTotalAmount(swimPrice, clubPrice);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }

        });

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


    }

    public void getTotalAmount(String d, String e) {

        try {
            Double ctv = Double.parseDouble(d);
            Double stv = Double.parseDouble(e);
            Double tAmt = ctv + stv + 10000;


            System.out.println(ctv + " + " + stv + " = " + tAmt);

            totaltv.setText(tAmt.toString());
        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

}
