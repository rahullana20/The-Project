package com.hms.adapters;

import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hms.Model.ComplainModel;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;

public class ComplainAdapter extends RecyclerView.Adapter<ComplainAdapter.ViewHolder> {

    List<ComplainModel> items;
    private FragmentActivity mContext;

    public ComplainAdapter(FragmentActivity activity, ArrayList<String> title, ArrayList<String> message) {
        mContext = activity;
        items = new ArrayList<ComplainModel>();
        for (int i = 0; i < title.size(); i++) {
            ComplainModel item = new ComplainModel();
            item.setDate(title.get(i));
            item.setData(message.get(i));

            items.add(item);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.complain_list_item, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ComplainModel list = items.get(position);
        holder.date.setText(list.getDate());
        holder.data.setText(list.getData());
    }

    @Override
    public int getItemCount() { return items.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView date;
        public TextView data;

        public ViewHolder(View itemView) {
            super(itemView);

            date = itemView.findViewById(R.id.complaintitle);
            data = itemView.findViewById(R.id.complainmessage);

        }
    }
}
