package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.JavaClasses.DatabaseQueries;
import com.hms.R;


/**.
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragmentUser extends Fragment {
    View view;

    TextView jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec;

    String yearSpinnerfirst, yearSpinnerSecond, monthSpinnerSecond, accountsFirebase, getEmail;
    String emailFromFirebase, getEmailValue;

    String month, monthValue;

    String arrayMonth[], arrayMonthValue[] ;
    int i = 0;

    Boolean checkedEmail = false;
    Boolean checkedValueAnswer = false;
    DatabaseReference maintenancefetch = FirebaseDatabase.getInstance().getReference().child("Accounts");
    Spinner yearSpinner;
    Spinner monthSpinnerPdf;
    Spinner yearSpinnerPdf;
    Button downloadPdf;
    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    public MaintenanceFragmentUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // return inflater.inflate(R.layout.MaintenanceFragmentUser, container, false);
        view = inflater.inflate(R.layout.fragment_maintenance_user, container, false);

        DatabaseReference ref = FirebaseDatabase.getInstance().getReference().child("Accounts");
        DatabaseReference maintenancefetch = FirebaseDatabase.getInstance().getReference().child("Accounts");

        jan = view.findViewById(R.id.janStatus);
        feb = view.findViewById(R.id.febStatus);
        mar = view.findViewById(R.id.marStatus);
        apr = view.findViewById(R.id.aprStatus);
        may = view.findViewById(R.id.mayStatus);
        jun = view.findViewById(R.id.janStatus);
        jul = view.findViewById(R.id.julStatus);
        aug = view.findViewById(R.id.augStatus);
        sep = view.findViewById(R.id.sepStatus);
        oct = view.findViewById(R.id.octStatus);
        dec = view.findViewById(R.id.decStatus);

        yearSpinner= view.findViewById(R.id.yearspinneruser);
        monthSpinnerPdf= view.findViewById(R.id.monthspinnerpdf);
        yearSpinnerPdf = view.findViewById(R.id.yearspinnerpdf);

        downloadPdf = view.findViewById(R.id.downloadpdf);

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);

        yearSpinner.setAdapter(adapterYears);
        monthSpinnerPdf.setAdapter(adapterMonths);
        yearSpinnerPdf.setAdapter(adapterYears);

        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerfirst = yearSpinner.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        monthSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                monthSpinnerSecond = monthSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        yearSpinnerPdf.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                yearSpinnerSecond = yearSpinnerPdf.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        downloadPdf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        //name of the accounts
        ref.addChildEventListener(new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try{
                    accountsFirebase = dataSnapshot.getKey(); //Deepak Jain
                    System.out.println("Account"+accountsFirebase);
                    checkedValueAnswer = getEmailKey(accountsFirebase);

                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        return view;
    }

    //get email as a key
    public boolean getEmailKey(String accounts){//Deepak Jain
        try {
            DatabaseReference refEmail = FirebaseDatabase.getInstance().getReference().child("Accounts").child(accounts);//Deepak Jain

        final String accountsValue = accounts;//Deepak Jain

        refEmail.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    //True if the authentication and database(email) matches
                    if (checkedEmail == true) {
                        Toast.makeText(getActivity(), "Email Verified", Toast.LENGTH_SHORT).show();
                        return;
                    } else if (checkedEmail == false){
                        getEmail = dataSnapshot.getKey();//EmailId
                        getEmailValue = dataSnapshot.getValue(String.class);//deepak.jain186@gmail.com

                        System.out.println(getEmail + " " + getEmailValue);
                        //true
                        checkedEmail = checkEmail(accountsValue, getEmail, getEmailValue);
                        return;
                    }
                }catch (Exception e){
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }catch (Exception e){

        }
        return checkedEmail;
    }

    public boolean checkEmail(String accounts, String email, String emailValue){

        if (email.equals("EmailId")){

            //DatabaseReference refValue = FirebaseDatabase.getInstance().getReference().child("Accounts").child(accounts).child(email);
            FirebaseAuth mAuth = FirebaseAuth.getInstance();
            emailFromFirebase = mAuth.getCurrentUser().getEmail();

            Toast.makeText(getActivity(), emailFromFirebase, Toast.LENGTH_SHORT).show();

            if (emailFromFirebase.equals(emailValue)){
                //                //Data Fetch
                maintenanceFetchDatabase(accounts);
                return true;
            }
        }
        return false;
    }

    public void maintenanceFetchDatabase(String accounts){
        maintenancefetch.child(accounts).child("Maintenance").child(yearSpinnerfirst);
        maintenancefetch.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                month = dataSnapshot.getKey();
                monthValue = dataSnapshot.getValue(String.class);

                arrayMonth[i] = month;
                arrayMonthValue[i] = monthValue;
                i++;

                updateValue(arrayMonth, arrayMonthValue);
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

    public void updateValue(String arrayMonth[], String arrayMonthValue[]){
        jan.setText(arrayMonthValue[0]);
        feb.setText(arrayMonthValue[1]);
    }
}
