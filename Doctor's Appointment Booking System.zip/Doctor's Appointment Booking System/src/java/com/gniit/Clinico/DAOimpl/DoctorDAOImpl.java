/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.gniit.Clinico.DAOimpl;

import DB_Connection.DBconnection;
import com.gniit.Clinico.Entity.Doctor;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.gniit.Clinico.DoctorDAO.DoctorDAO;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;

/**
 *
 * @author Namrata
 */
public class DoctorDAOImpl implements DoctorDAO{

   
    public int addDoctor(Doctor doctor) {
        Connection con=DBconnection.getConnection();
    
  
        int count=0;
       
        try {
             String query="insert into Doctors(DoctorId,dName,dSpecialist,dEmailId,dContactNo) values(?,?,?,?,?)";
             
      PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,doctor.getDoctor_ID());
            pst.setString(2,doctor.getName()); 
            pst.setString(3,doctor.getSpecialist());
              pst.setString(4,doctor.getEmail_ID());
                pst.setInt(5,doctor.getContact_No());
                
            count = pst.executeUpdate();
           
        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
 
        return count;
    }

    @Override
    public int deleteDoctor(int Doctor_ID) {
        int count=0;
        try {
            
   Connection con=DBconnection.getConnection();         
            PreparedStatement preparedStatement = con.prepareStatement("delete from Doctors where DoctorId=?");
            preparedStatement.setInt(1,Doctor_ID);
            count=preparedStatement.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
        
        
        
    }

    @Override
    public List<Doctor> getDoctors() {
        List<Doctor> doctorList = null;
        try {
            Connection con=DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Doctors");
            ResultSet rs = preparedStatement.executeQuery();
            doctorList = new ArrayList<Doctor>();
            if(rs!=null){
               
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String specialist = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                    String dpass=rs.getString(6);
                  
                    Doctor doctor = new Doctor(id,name,specialist,emailid,contactno,dpass);
                    doctorList.add(doctor);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     return doctorList;

        
      
    }

    @Override
    public Doctor getDoctorByID(int Doctor_ID) {
        List<Doctor> doctorList = null;
        try {
            Connection con = DBconnection.getConnection(); 
            PreparedStatement preparedStatement = con.prepareStatement("select * from Doctors where DoctorId=?");
            preparedStatement.setInt(1, Doctor_ID);
            ResultSet rs = preparedStatement.executeQuery();
           doctorList = new ArrayList<Doctor>();
            if(rs!=null){
            
                while(rs.next()){
                    int id = rs.getInt(1);
                    String name = rs.getString(2);
                    String specialist = rs.getString(3);
                    String emailid = rs.getString(4);
                    int contactno = rs.getInt(5);
                    String dpass=rs.getString(6);
                    Doctor doctor = new Doctor(id,name,specialist,emailid,contactno,dpass);
                    doctorList.add(doctor);
                }
            }
            
            
        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
     if(doctorList.size()>0) return doctorList.get(0);
     else return null;
        
    }

    @Override
    public int updateDoctor(int Doctor_ID, Doctor doctor) {
        int count=0;
        try {
            Connection con  = DBconnection.getConnection();
            
            String query="update Doctors set dName=?, dSpecialist=?, dEmailId=?, dContactNo=? where DoctorId=?";
            PreparedStatement pst=con.prepareStatement(query);
             pst.setInt(1,doctor.getDoctor_ID());
            pst.setString(2,doctor.getName());
            pst.setString(3,doctor.getSpecialist());
              pst.setString(4,doctor.getEmail_ID());
                pst.setInt(5,doctor.getContact_No());
                
                  count=pst.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        return count;
    }
    @Override
  public boolean isValidate(String Email_ID)
 {
      boolean result = true;
   try {
      InternetAddress emailAddr = new InternetAddress(Email_ID);
      emailAddr.validate();
   } catch (AddressException ex) {
      result = false;
   }
   return result;
}
    @Override
    public boolean validUser(int Doctor_ID, String dpassword)
 {
 try {
          Connection con = DBconnection.getConnection();
          PreparedStatement pst = con.prepareStatement("select PatientId, password from doctors where DoctorId = ? and dpassword = ?");

          pst.setInt(1,Doctor_ID);
          pst.setString(2, dpassword);

          ResultSet rs = pst.executeQuery();
          String rsUserName = null;
          String rsPassword = null;
          if(rs.next()){
              rsUserName = rs.getString("Doctor_ID");
              rsPassword =  rs.getString("dpassword");    
          }

          con.close();

          if (rsUserName.equals(Doctor_ID) && rsPassword.equals(dpassword)){
              return true;
          }



        } catch (SQLException ex) {
            Logger.getLogger(DoctorDAOImpl.class.getName()).log(Level.SEVERE, null, ex);

        }
        return false; 
      }

        
    }
    

