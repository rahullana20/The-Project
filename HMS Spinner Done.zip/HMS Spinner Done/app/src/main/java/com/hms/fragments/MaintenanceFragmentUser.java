package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.hms.R;


/**.
 * A simple {@link Fragment} subclass.
 */
public class MaintenanceFragmentUser extends Fragment {
    View view;
    Spinner monthSpinner;
    Spinner yearSpinner;
    String []months=new String[]{"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
    String []years=new String[]{"2015","2016","2017","2018"};
    public MaintenanceFragmentUser() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       // return inflater.inflate(R.layout.MaintenanceFragmentUser, container, false);
        view = inflater.inflate(R.layout.fragment_maintenance_user, container, false);
        monthSpinner= (Spinner) view.findViewById(R.id.monthspinner);
        yearSpinner=(Spinner) view.findViewById(R.id.yearspinner);

        ArrayAdapter adapterMonths = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,months);
        ArrayAdapter adapterYears = new ArrayAdapter(getActivity(),android.R.layout.simple_list_item_1,years);
        monthSpinner.setAdapter(adapterMonths);
        yearSpinner.setAdapter(adapterYears);
        return view;
    }

}
