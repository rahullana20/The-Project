package com.hms.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class BillReportsFragment extends Fragment {
   //  String accountsFirebase, accountFirebase2,  yearPassedFunction, namePassedFunction;

    View view;
    Spinner nameSpinnerRep, yearSpinnerRep;
    private TextView jan, feb, mar, apr, may, jun, jul, aug, sep, oct, nov, dec;
    List<String> names = new ArrayList<>();

    String[] years = new String[]{"2018","2017","2016","2015"};
    String name, year, month, monthValue, yearValue, nameValue;
    String value;

    DatabaseReference ref;
    DatabaseReference yearRef;
    public BillReportsFragment() {
        // Required empty public constructor
    }

    /*public void setNameValue(String nameVal) {
        namePassedFunction = nameVal;
        System.out.println("Function Value: " + namePassedFunction + " Passed Value "+ nameVal);
    }
    public void setYearValue(String yearVal){
        yearPassedFunction = yearVal;
        System.out.println("Function Value: " + yearPassedFunction + " Passed Value "+ yearVal);
    }*/

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Bill Report");
        view = inflater.inflate(R.layout.fragment_reports, container, false);

        ref = FirebaseDatabase.getInstance().getReference().child("Accounts");
        yearRef = ref.child("Maintenance").child("Years");

        nameSpinnerRep = view.findViewById(R.id.nameSpinnerReport);
        yearSpinnerRep = view.findViewById(R.id.yearSpinnerReport);

        jan = view.findViewById(R.id.janStatusAdmin);
        feb = view.findViewById(R.id.febStatusAdmin);
        mar = view.findViewById(R.id.marStatusAdmin);
        apr = view.findViewById(R.id.aprStatusAdmin);
        may = view.findViewById(R.id.mayStatusAdmin);
        jun = view.findViewById(R.id.junStatusAdmin);
        jul = view.findViewById(R.id.julStatusAdmin);
        aug = view.findViewById(R.id.augStatusAdmin);
        sep = view.findViewById(R.id.sepStatusAdmin);
        oct = view.findViewById(R.id.octStatusAdmin);
        nov = view.findViewById(R.id.novStatusAdmin);
        dec = view.findViewById(R.id.decStatusAdmin);

        final ArrayAdapter<String> adapterName = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, names);
        adapterName.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        nameSpinnerRep.setAdapter(adapterName);

        final ArrayAdapter<String> adapterYears = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1, years);
        adapterYears.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinnerRep.setAdapter(adapterYears);

        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
               final String accountsFirebase = dataSnapshot.getKey();
                final String accountFirebase2 = accountsFirebase;

                names.add(accountsFirebase);
                adapterName.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        nameSpinnerRep.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                name = nameSpinnerRep.getItemAtPosition(i).toString();

                System.out.println("Selected Name: " + name);
                Toast.makeText(getActivity(), name, Toast.LENGTH_SHORT).show();

         //       mainFetch(name);
                fetchYear(name);
                //setNameValue(name);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



          //System.out.println("Year Passed: " + yearPassedFunction + " Account Passed: " + namePassedFunction);


            //mainFetch(accountFirebase2,yearFirebase2);
        return view;
    }
    public void fetchYear(final String name){
        yearSpinnerRep.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                year = yearSpinnerRep.getItemAtPosition(i).toString();
                //  setYearValue(year);
                mainFetch(name, year);
                System.out.println("Selected Year: " + year);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }


    public void mainFetch(String accountsFirebase, String year){

        System.out.println("Name: " + accountsFirebase);

        DatabaseReference monthFetch = FirebaseDatabase.getInstance().getReference("Accounts").child(accountsFirebase);
        monthFetch = monthFetch.child("Maintenance").child(year);

        monthFetch.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                try {
                    month = dataSnapshot.getKey();
                    monthValue = (String) dataSnapshot.getValue();

                    System.out.println(month + "'s Maintenance: " + monthValue);

                    if (month.equals("Jan")) {
                        jan.setText(monthValue);
                    }
                    if (month.equals("Feb")) {
                        feb.setText(monthValue);
                    }
                    if (month.equals("Mar")) {
                        mar.setText(monthValue);
                    }
                    if (month.equals("Apr")) {
                        apr.setText(monthValue);
                    }
                    if (month.equals("May")) {
                        may.setText(monthValue);
                    }
                    if (month.equals("Jun")) {
                        jun.setText(monthValue);
                    }
                    if (month.equals("Jul")) {
                        jul.setText(monthValue);
                    }
                    if (month.equals("Aug")) {
                        aug.setText(monthValue);
                    }
                    if (month.equals("Sep")) {
                        sep.setText(monthValue);
                    }
                    if (month.equals("Oct")) {
                        oct.setText(monthValue);
                    }
                    if (month.equals("Nov")) {
                        nov.setText(monthValue);
                    }
                    if (month.equals("Dec")) {
                        dec.setText(monthValue);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                try {
                    month = dataSnapshot.getKey();
                    monthValue = (String) dataSnapshot.getValue();

                    System.out.println(month + "'s Maintenance: " + monthValue);

                    if (month.equals("Jan")) {
                        jan.setText(monthValue);
                    }
                    if (month.equals("Feb")) {
                        feb.setText(monthValue);
                    }
                    if (month.equals("Mar")) {
                        mar.setText(monthValue);
                    }
                    if (month.equals("Apr")) {
                        apr.setText(monthValue);
                    }
                    if (month.equals("May")) {
                        may.setText(monthValue);
                    }
                    if (month.equals("Jun")) {
                        jun.setText(monthValue);
                    }
                    if (month.equals("Jul")) {
                        jul.setText(monthValue);
                    }
                    if (month.equals("Aug")) {
                        aug.setText(monthValue);
                    }
                    if (month.equals("Sep")) {
                        sep.setText(monthValue);
                    }
                    if (month.equals("Oct")) {
                        oct.setText(monthValue);
                    }
                    if (month.equals("Nov")) {
                        nov.setText(monthValue);
                    }
                    if (month.equals("Dec")) {
                        dec.setText(monthValue);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}