package com.hms.adapters;

import android.support.annotation.NonNull;
import android.support.v4.app.FragmentActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.hms.Model.UserReportModel;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;

public class UserReportAdapter extends RecyclerView.Adapter<UserReportAdapter.ViewHolder>{
    List<UserReportModel> items;
    private FragmentActivity mContext;

    public UserReportAdapter(FragmentActivity activity, ArrayList<String> name, ArrayList<String> plot) {
        mContext = activity;
        items = new ArrayList<UserReportModel>();
        for (int i = 0; i < name.size(); i++) {
            UserReportModel item = new UserReportModel();
            item.setUsers(name.get(i));
            item.setPlot_no(plot.get(i));

            items.add(item);
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.user_report_list_item, parent, false);
        return new UserReportAdapter.ViewHolder(v);
    }



    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UserReportModel list = items.get(position);
        holder.users.setText(list.getUsers());
        holder.plot_no.setText(list.getPlot_no());
    }

    @Override
    public int getItemCount() { return items.size(); }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView users;
        public TextView plot_no;

        public ViewHolder(View itemView) {
            super(itemView);

            users = itemView.findViewById(R.id.user);
            plot_no = itemView.findViewById(R.id.plot);

        }
    }
}
