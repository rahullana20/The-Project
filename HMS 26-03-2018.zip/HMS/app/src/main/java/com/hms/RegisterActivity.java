package com.hms;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener{

    AutoCompleteTextView name;
    AutoCompleteTextView email;
    EditText password;
    AutoCompleteTextView plot_no;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button sign_up;

    private ProgressDialog progressDialog;

    private FirebaseAuth mAuth;

    TextView loginLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null)
        {
            //start the main profile
            finish();
            startActivity(new Intent(this, MainActivity.class));
        }

        progressDialog = new ProgressDialog(this);

        loginLink = (TextView) findViewById(R.id.labeltextview);
        name = (AutoCompleteTextView) findViewById(R.id.fullname);
        email = (AutoCompleteTextView) findViewById(R.id.emailRegister);
        password = (EditText) findViewById(R.id.password);
        plot_no = (AutoCompleteTextView) findViewById(R.id.plotno);
        number_of_members = (AutoCompleteTextView) findViewById(R.id.totalmembers);
        contact_no = (AutoCompleteTextView) findViewById(R.id.contactno);
        swimming_pool = (CheckBox) findViewById(R.id.swimmingpoolcb);
        sports_club = (CheckBox) findViewById(R.id.sportsclubcb);
        aadhar_card_no = (AutoCompleteTextView) findViewById(R.id.aadharno);
        sign_up = (Button) findViewById(R.id.sign_up_register);

        loginLink.setOnClickListener(this);
        sign_up.setOnClickListener(this);

        isOnline();
    }

        @Override
        public void onClick(View view) {

            if (view == sign_up)
            {
                //fetching data
                String Name = name.getText().toString().trim();
                String emailId = email.getText().toString().trim();
                String pass = password.getText().toString().trim();
                String plot = plot_no.getText().toString().trim();
                String countmembers = number_of_members.getText().toString().trim();
                String contact = contact_no.getText().toString();
                String aadhar = aadhar_card_no.getText().toString().trim();

                String checkSwim, checkSports;

                if(swimming_pool.isChecked())
                {
                    checkSwim = "Yes";
                }
                else
                {
                    checkSwim = "No";
                }

                if(sports_club.isChecked())
                {
                    checkSports = "Yes";
                }
                else
                {
                    checkSports = "No";
                }

                if (TextUtils.isEmpty(Name))
                {
                    Toast.makeText(this, "Name cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }
                else if (TextUtils.isEmpty(plot))
                {
                    Toast.makeText(this, "Plot Number cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }
                else if (TextUtils.isEmpty(emailId))
                {
                    Toast.makeText(this, "Email ID cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }
                else if (TextUtils.isEmpty(pass))
                {
                    Toast.makeText(this, "Password cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }

                else if (TextUtils.isEmpty(countmembers))
                {
                    Toast.makeText(this, "Number of members cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }
                else if (TextUtils.isEmpty(contact))
                {
                    Toast.makeText(this, "Contact Number cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }
                else if (TextUtils.isEmpty(aadhar))
                {
                    Toast.makeText(this, "Aadhar cannot be blank", Toast.LENGTH_LONG).show();
                    return;
                }

                progressDialog.setMessage("Registering User");
                progressDialog.show();

                mAuth.createUserWithEmailAndPassword(emailId,pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            progressDialog.dismiss();
                            finish();
                            startActivity(new Intent(RegisterActivity.this, MainActivity.class));
                        }
                        else
                        {
                            Toast.makeText(RegisterActivity.this,"Please check your internet connection",Toast.LENGTH_LONG).show();

                            plot_no.getText().clear();
                            email.getText().clear();
                            password.getText().clear();
                            number_of_members.getText().clear();
                            contact_no.getText().clear();
                            aadhar_card_no.getText().clear();
                            name.getText().clear();
                            return;
                        }
                    }

                });

        DatabaseQueries dq = new DatabaseQueries();
        dq.updateRegister(Name,emailId, pass, plot, countmembers, contact, aadhar, checkSwim, checkSports);

                }

            else if (view == loginLink)
            {
                finish();
                startActivity(new Intent(RegisterActivity.this, LoginExample.class));
            }

        }

    public boolean isOnline() {
        try {
            boolean haveConnectedWifi = false;
            boolean haveConnectedMobile = false;

            ConnectivityManager cm = (ConnectivityManager) this.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetwork = cm.getActiveNetworkInfo();

            // connected to the internet
            if (activeNetwork != null)
                if (activeNetwork.getType() == ConnectivityManager.TYPE_WIFI) {

                    // connected to wifi
                    haveConnectedWifi = true;

                } else if (activeNetwork.getType() == ConnectivityManager.TYPE_MOBILE) {
                    // connected to the mobile provider's data plan
                    haveConnectedMobile = true;
                }
            return haveConnectedWifi || haveConnectedMobile;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}



