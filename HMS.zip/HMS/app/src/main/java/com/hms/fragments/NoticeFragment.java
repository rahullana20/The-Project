package com.hms.fragments;


import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.R;
import com.hms.adapters.NoticeAdapter;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 */
public class NoticeFragment extends Fragment {

    FloatingActionButton plus;
    View view;
    FirebaseDatabase data;
    DatabaseReference ref;
    private ArrayList<String> title = new ArrayList<>();
    private ArrayList<String> message = new ArrayList<>();
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView noticeList;
    private  NoticeAdapter noticeAdapter;

    public NoticeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_notice, container, false);

        noticeList = view.findViewById(R.id.notice_list);
        plus = view.findViewById(R.id.plusNotice);

        if (plus!=null) {
            plus.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Fragment fragment = new NoticeAddAdminFragment();
                    FragmentManager fragmentManager = getFragmentManager();
                    fragmentManager.beginTransaction().replace(R.id.activity_main, fragment).commit();
                }
            });
        }

        try{
        ref = FirebaseDatabase.getInstance().getReference("Notice").child("3MpXje3ULfa8aBhyJbq0rGi0YMN2");

        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                String value = dataSnapshot.getValue(String.class);

                message.add(value);

                String key = dataSnapshot.getKey();
                title.add(key);
                noticeAdapter =  new NoticeAdapter(getActivity(),title,message);

                layoutManager = new LinearLayoutManager(getActivity());
                noticeList.setLayoutManager(layoutManager);

                noticeList.setAdapter(noticeAdapter);
                //noticeAdapter.notifyDataSetChanged();

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
        }catch (Exception e){}

        return view;
    }

}
