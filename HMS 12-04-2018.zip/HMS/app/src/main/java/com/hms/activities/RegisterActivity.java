package com.hms.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.hms.CommonMethods;
import com.hms.DatabaseQueries;
import com.hms.R;

public class RegisterActivity extends AppCompatActivity implements View.OnClickListener {
    AutoCompleteTextView name;
    AutoCompleteTextView email;
    EditText password;
    AutoCompleteTextView plot_no;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button sign_up;

    private ProgressDialog progressDialog;
    private FirebaseAuth mAuth;

    TextView loginLink;
    final String value = "deepak.jain186@gmail.com";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        mAuth = FirebaseAuth.getInstance();

        if (CommonMethods.isOnline(getBaseContext())) {
            try {
                if (mAuth.getCurrentUser().getEmail().equals(value)) {
                    startActivity(new Intent(this, AdminActivity.class));
                } else if (mAuth.getCurrentUser() != null) {
                    //start the main profile
                    finish();
                    startActivity(new Intent(this, UserActivity.class));
                }
            }catch (Exception e){}
        }
        else {
            Toast.makeText(this, "Please check internet connection", Toast.LENGTH_SHORT).show();
        }

        progressDialog = new ProgressDialog(this);

        loginLink = findViewById(R.id.labeltextview);
        name = findViewById(R.id.fullname);
        email = findViewById(R.id.emailRegister);
        password = findViewById(R.id.password);
        plot_no = findViewById(R.id.plotno);
        number_of_members = findViewById(R.id.totalmembers);
        contact_no = findViewById(R.id.contactno);
        swimming_pool = findViewById(R.id.swimmingpoolcb);
        sports_club = findViewById(R.id.sportsclubcb);
        aadhar_card_no = findViewById(R.id.aadharno);
        sign_up = findViewById(R.id.sign_up_register);

        loginLink.setOnClickListener(this);
        sign_up.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {

        if (view == sign_up) {
            //fetching data
            final String Name = name.getText().toString().trim();
            final String emailId = email.getText().toString().trim();
            final String pass = password.getText().toString().trim();
            final String plot = plot_no.getText().toString().trim();
            final String countMembers = number_of_members.getText().toString().trim();
            final String contact = contact_no.getText().toString();
            final String aadhar = aadhar_card_no.getText().toString().trim();

            final String checkSwim, checkSports;
            if (swimming_pool.isChecked()) {
                checkSwim = "Yes";
            } else {
                checkSwim = "No";
            }
            if (sports_club.isChecked()) {
                checkSports = "Yes";
            } else {
                checkSports = "No";
            }

            if (TextUtils.isEmpty(Name)) {
                Toast.makeText(this, "Name cannot be blank", Toast.LENGTH_LONG).show();
                name.setError("Enter name");
                return;
            } else if (TextUtils.isEmpty(plot)) {
                Toast.makeText(this, "Plot Number cannot be blank", Toast.LENGTH_LONG).show();
                email.setError("Enter plot number");
                return;
            } else if (TextUtils.isEmpty(emailId)) {
                Toast.makeText(this, "Email ID cannot be blank", Toast.LENGTH_LONG).show();
                email.setError("Enter email address");
                return;
            } else if (TextUtils.isEmpty(pass)) {
                Toast.makeText(this, "Password cannot be blank", Toast.LENGTH_LONG).show();
                password.setError("Enter password");
                return;
            } else if (TextUtils.isEmpty(countMembers)) {
                Toast.makeText(this, "Number of members cannot be blank", Toast.LENGTH_LONG).show();
                number_of_members.setError("Enter number of members staying");
                return;
            } else if (TextUtils.isEmpty(contact)) {
                Toast.makeText(this, "Contact Number cannot be blank", Toast.LENGTH_LONG).show();
                contact_no.setError("Enter contact number");
                return;
            } else if (TextUtils.isEmpty(aadhar)) {
                Toast.makeText(this, "Aadhar cannot be blank", Toast.LENGTH_LONG).show();
                aadhar_card_no.setError("Enter aadhar number");
                return;
            }
            progressDialog.setMessage("Registering User");
            progressDialog.show();

            if (CommonMethods.isOnline(getBaseContext())) {
                mAuth.createUserWithEmailAndPassword(emailId, pass).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful() == true) {
                            progressDialog.dismiss();
                            DatabaseQueries dq = new DatabaseQueries();
                            dq.updateRegister(Name, emailId, pass, plot,countMembers, contact, aadhar,checkSwim,checkSports);
                            finish();
                            startActivity(new Intent(RegisterActivity.this, UserActivity.class));
                        }
                        else if (task.isSuccessful() == false)
                        {
                            progressDialog.dismiss();
                            Toast.makeText(RegisterActivity.this, "PLease enter valid data.", Toast.LENGTH_SHORT).show();
                            name.getText().clear();
                            plot_no.getText().clear();
                            email.getText().clear();
                            password.getText().clear();
                            number_of_members.getText().clear();
                            contact_no.getText().clear();
                            aadhar_card_no.getText().clear();
                            name.requestFocus();
                            return;
                        }
                    }
                });
            } else {
                progressDialog.dismiss();
                Toast.makeText(this, "Please check your internet connection", Toast.LENGTH_SHORT).show();
            }
        }
        else if (view == loginLink) {
            finish();
            startActivity(new Intent(RegisterActivity.this, Login.class));
        }
    }
}