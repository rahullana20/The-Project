package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.android.gms.tasks.OnCompleteListener;
import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateMemberFragment extends Fragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    View view;
    Spinner updateSpinner;
    AutoCompleteTextView name;
    AutoCompleteTextView number_of_members;
    AutoCompleteTextView contact_no;
    CheckBox swimming_pool;
    CheckBox sports_club;
    AutoCompleteTextView aadhar_card_no;
    Button update;
    public UpdateMemberFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_update_member, container, false);

        updateSpinner=(Spinner)view.findViewById(R.id.updatespinner);
        name=(AutoCompleteTextView)view.findViewById(R.id.fullname);
        number_of_members=(AutoCompleteTextView)view.findViewById(R.id.updatetotalmembers);
        contact_no=(AutoCompleteTextView) view.findViewById(R.id.updatecontactno);
        swimming_pool = (CheckBox)view.findViewById(R.id.swimmingpoolcb);
        sports_club = (CheckBox)view.findViewById(R.id.sportsclubcb);
        aadhar_card_no =(AutoCompleteTextView)view.findViewById(R.id.updateaadharno);
        update=(Button) view.findViewById(R.id.updateButton);

        update.setOnClickListener(this);


        return view;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
