package com.hms.fragments;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.hms.CommonMethods;
import com.hms.DatabaseQueries;
import com.hms.R;

import java.util.ArrayList;
import java.util.List;

import static android.widget.Toast.makeText;

/**
 * A simple {@link Fragment} subclass.
 */
public class UpdateMemberFragment extends Fragment {

    View view;
    Spinner updateSpinner;
    AutoCompleteTextView name, number_of_members, contact_no, aadhar_card_no;
    CheckBox swimming_pool, sports_club;
    Button update;

    String itemSelected;
    String value;
    ProgressBar progressBar;

    DatabaseReference ref;

    List<String> names = new ArrayList<>();

//    private ArrayList<String> names = new ArrayList<>();

    public UpdateMemberFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view= inflater.inflate(R.layout.fragment_update_member, container, false);

        updateSpinner= view.findViewById(R.id.updatespinner);
        name= view.findViewById(R.id.updatefullname);
        number_of_members= view.findViewById(R.id.updatetotalmembers);
        contact_no= view.findViewById(R.id.updatecontactno);
        swimming_pool = view.findViewById(R.id.swimmingpoolcb);
        sports_club = view.findViewById(R.id.sportsclubcb);
        aadhar_card_no = view.findViewById(R.id.updateaadharno);
        update=view.findViewById(R.id.updateButton);

        ref = FirebaseDatabase.getInstance().getReference().child("Accounts");

        final ArrayAdapter<String> adapterUpdateMember = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_spinner_item,names);
        adapterUpdateMember.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        updateSpinner.setAdapter(adapterUpdateMember);

        //adding data to spinner
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                value = String.valueOf(dataSnapshot.getKey());

                names.add(value);
                adapterUpdateMember.notifyDataSetChanged();
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

        //Fetching data from spinner
        updateSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                itemSelected = updateSpinner.getItemAtPosition(i).toString();
                Toast.makeText(getActivity(), itemSelected, Toast.LENGTH_LONG).show();
            }

            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        //updating values in database
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    final String Name = name.getText().toString().trim();
                    final String countMembers = number_of_members.getText().toString().trim();
                    final String contact = contact_no.getText().toString();
                    final String aadhar = aadhar_card_no.getText().toString().trim();
                    //  System.out.println("plot no="+ plot_no);
                    final String checkSwim, checkSports;
                    if (swimming_pool.isChecked()) {
                        checkSwim = "Yes";
                    } else {
                        checkSwim = "No";
                    }
                    if (sports_club.isChecked()) {
                        checkSports = "Yes";
                    } else {
                        checkSports = "No";
                    }

                    if (CommonMethods.isOnline(getActivity())) {

                        if (value.equals(itemSelected)) {
                            DatabaseQueries dq = new DatabaseQueries();
                            boolean check = dq.updateMember(Name, countMembers, contact, aadhar, checkSwim, checkSports);

                            if (check == true){
                                Toast.makeText(getActivity(), "Updating member's data was Unsuccessful", Toast.LENGTH_SHORT).show();
                            }
                            else if (check == false){
                                Toast.makeText(getActivity(), "Member's Data Updated Successfully", Toast.LENGTH_SHORT).show();
                            }

                        } else {
                            makeText(getActivity(), "Something went wrong, Please try again!", Toast.LENGTH_SHORT).show();
                        }

                    } else {
                        makeText(getActivity(), "Please check your internet connection", Toast.LENGTH_SHORT).show();
                    }
                }catch (Exception e){}

            }
        });

        return view;
    }

}
