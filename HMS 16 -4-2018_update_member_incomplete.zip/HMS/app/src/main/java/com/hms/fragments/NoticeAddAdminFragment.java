package com.hms.fragments;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.hms.CommonMethods;
import com.hms.DatabaseQueries;
import com.hms.R;

/**
 * A simple {@link Fragment} subclass.
 */
public class NoticeAddAdminFragment extends Fragment {

    EditText titleNotice, messageNotice;
    Button submit;
    View view;
    private ProgressDialog progressDialog;
    public NoticeAddAdminFragment() {
        // Required empty public constructor
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        Toolbar toolbar = getActivity().findViewById(R.id.toolbar);
        toolbar.setTitle("Add a Notice");
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_notice_admin, container, false);

        //progressDialog = new ProgressDialog(getActivity());

        titleNotice = (EditText) view.findViewById(R.id.noticeTitle);
        messageNotice = (EditText) view.findViewById(R.id.noticeMessage);
        submit = view.findViewById(R.id.sendNotice);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String title = titleNotice.getText().toString().trim();
                final String message = messageNotice.getText().toString().trim();

                if (TextUtils.isEmpty(title)) {
                    titleNotice.setError("Enter Notice Title");
                    return;
                }
                else if (TextUtils.isEmpty(message)) {
                    messageNotice.setError("Enter a detailed description");
                    return;
                }
            //    progressDialog.setMessage("Adding a Notice");
              //  progressDialog.show();
                new ConnectBT().execute();
                if (CommonMethods.isOnline(getActivity())) {
                    progressDialog.dismiss();
                    DatabaseQueries dq = new DatabaseQueries();
                    boolean flag = dq.addNotice(title,message);
                    if (flag == true){
                        Toast.makeText(getContext(), "Notice not sent, Please try again!", Toast.LENGTH_SHORT).show();
                        titleNotice.getText().clear();
                        messageNotice.getText().clear();
                        titleNotice.requestFocus();
                    }else if(flag == false){
                        Toast.makeText(getContext(), "Notice Added Successfully!", Toast.LENGTH_SHORT).show();
                        titleNotice.getText().clear();
                        messageNotice.getText().clear();
                        titleNotice.requestFocus();
                    }
                }else {
                    progressDialog.dismiss();
                    Toast.makeText(getContext(), "Please check your internet connection", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    private class ConnectBT extends AsyncTask<Void, Void, Void>  // UI thread
    {
        private boolean ConnectSuccess = true; //if it's here, it's almost connected

        @Override
        protected void onPreExecute() {
            progressDialog = ProgressDialog.show(getActivity(), "Connecting...", "Please wait!!!");  //show a progress dialog
        }

        @Override
        protected Void doInBackground(Void... devices) //while the progress dialog is shown, the connection is done in background
        {
           return null;
        }
        @Override
        protected void onPostExecute(Void result) //after the doInBackground, it checks if everything went fine
        {
            super.onPostExecute(result);
        }

    }

}
